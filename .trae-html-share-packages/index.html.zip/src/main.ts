import "./data/storageMigration"; // first: carry saved state over from the pre-rename keys
import "./render/frameCap"; // second: the desktop app's 300 fps cap patches requestAnimationFrame
// The shared UI kit (packages/ui) first, so the game's own sheet can lay its pieces out.
import "@warcraft-open/ui/fonts.css";
import "@warcraft-open/ui/ui.css";
import "./style.css";
// First, so its capture listener is the page's first: Alt+Enter must reach nothing else.
import "./ui/fullscreen";
// …and before any button exists: a press is the left button's (`ow3-alt-press`).
import "./ui/primaryPress";
import { AssetResolver } from "./assets/resolver";
import { setDbgEnabled } from "./dev/dbg";
import { decodeBlp } from "./assets/blp";
import { mountMainMenu } from "./ui/mainMenu";
import { mountFdfMainMenu } from "./ui/fdfMainMenu";
import { mountHdMainMenu } from "./ui/hd/mainMenu";
import { mountHdSinglePlayer } from "./ui/hd/singlePlayer";
import { mountHdCampaign } from "./ui/hd/campaign";
import { mountHdOptions } from "./ui/hd/options";
import { mountHdSkirmish } from "./ui/hd/skirmish";
import { mountHdCustomCampaign } from "./ui/hd/customCampaign";
import { mountHdViewReplay } from "./ui/hd/replay";
import { mountSinglePlayerMenu, singlePlayerSides } from "./ui/fdfSinglePlayerMenu";
import { mountSkirmish } from "./ui/fdfSkirmish";
import { mountCampaignScreen, type CampaignScreenState } from "./ui/fdfCampaign";
import { mountCustomCampaignScreen } from "./ui/fdfCustomCampaign";
import { mountViewReplayScreen, replayMapPath } from "./ui/fdfViewReplay";
import { replayBoot, replayBridge } from "./replayBoot";
import { patchLevel, setPatchLevel } from "./patches";
import { decodeReplay, fnv64, replayRefusalText, type Replay, type ReplayView } from "./game/replay";
import { replaySink } from "./game/replaySink";

/** Warcraft Open's version, from package.json (vite.config.ts `define`). */
declare const __OW3_VERSION__: string;
import { creditsMap, loadCampaigns, type Campaign, type CampaignEntry } from "./data/campaigns";
import { isRoc, setEdition, setMapDataSet } from "./data/edition";
import { flavor, isHd } from "./data/flavor";
import { gameVersion, setGameVersion } from "./data/gameVersion";
import { setSaveHost, type LiveSave } from "./game/saveManager";
import type { SaveScript } from "./game/saveFile";
import type { WorldSnapshot } from "./game/snapshot";
import {
  isCampaignOpen, loadDifficulty, markMissionComplete, saveDifficulty, type Difficulty,
} from "./data/campaignProgress";
import { mountLanScreen, observerSeats, savedPlayerName, toConfig } from "./ui/fdfLan";
import { mountHdLanScreen } from "./ui/hd/lan";
import { mountHdLanCreateScreen } from "./ui/hd/lanCreate";
import { mountHdLanLobbyScreen } from "./ui/hd/lanLobby";
import { localMapPath } from "./assets/downloadedMaps";
import { mountLanCreateScreen } from "./ui/fdfLanCreate";
import { mountLanLobbyScreen } from "./ui/fdfLanLobby";
import { LanLobby } from "./net/lobby";
import { OFFICIAL_SERVERS } from "./net/officialServer";
import { observerSlots } from "./net/lobbySetup";
import type { AdvancedOptions } from "./net/advancedOptions";
import { WebSocketTransport } from "./net/transport";
import { isDesktopApp, onServersFound, onShellClosing } from "./assets/nativeInstall";
import { watchForUpdates } from "./ui/updatePrompt";
import { startGamepad } from "./ui/gamepad";
import { installMouseCapture } from "./ui/mouseCapture";
import { mountOptions } from "./ui/fdfOptions";
import { applyAudioOptions, loadOptions } from "./data/options";
import { profilePlayerName } from "./data/profiles";
import { applyVideoOptions } from "./render/videoQuality";
import { applyHealthBarOptions } from "./render/worldOverlays";
import { applyHotkeyOptions } from "./data/hotkeys";
import { applyScrollOptions } from "./render/scrollOptions";
import { applyVoiceOptions, setMenuVoiceHost, voiceHear, voicePrerollState, voiceSay } from "./voice/control";
import { forgetOldVoiceModels } from "./voice/model";
import { makeMenuVoiceHost } from "./voice/menu";
import { GlueManager, WORLD_FADE_MS, type GlueScreenDef } from "./ui/glue";
import { mountLoadingScreen, type LoadingScreen } from "./ui/loadingScreen";
import { mountHdLoadingScreen } from "./ui/hd/loading";
import { mountScoreScreen, scoreScreenMusic } from "./ui/scoreScreen";
import { mountHdScoreScreen } from "./ui/hd/score";
import type { ScoreTable } from "./game/scoreTable";
import { mountLoadGate, type GateLoad } from "./ui/gate";
import { mountHome, type Home } from "./ui/home";
import { setFdfClickSound, type FdfScreen } from "./ui/fdf/render";
import { GlueAudio } from "./ui/glueAudio";
import { SoundBoard } from "./audio/sounds";
import type { DataSource } from "./vfs/types";
import type { MeleeConfig, SlotConfig } from "./ui/lobby";
import { readMapInfo, readMapPreviewBytes } from "./ui/mapBrowser";
import { showGlueDialog } from "./ui/glueDialog";
import { startsExplored } from "./world/mapKind";
import type { MapPreview } from "./world/mapPreview";
import { parseMapInfo, type MapInfo, type NeutralPlayer, type PlayerSlot } from "./world/mapInfo";
import { loadUnitRegistry } from "./data/units";
import { TerrainScene } from "./render/scene";
import { buildTerrainMesh } from "./render/terrainMesh";
import { makePlaceholderTerrain } from "./world/placeholderTerrain";
import { loadMapBytes } from "./world/map";
import { readMapBytes } from "./vfs/mapArchive";
import { LayeredDataSource } from "./vfs/layered";
import { MpqDataSource } from "./vfs/mpq";
import { ModelViewerScene, type SequenceInfo } from "./render/modelViewer";
import { MapViewerScene, lastRecordedReplay, mapLoadRefusal } from "./render/mapViewer";
import { matchLinkFrom, type MatchLinkSetup } from "./game/matchLink";
import { LoadGate } from "./game/loadGate";
import { MenuScene } from "./render/menuScene";
import { applyMenuCursor } from "./ui/cursor";
import { applyGameFont } from "./ui/gameFont";
import { setGameTipSkin } from "./ui/gameTip";
import { tooltipSkinVars } from "./ui/hud";
import { blpToCanvas } from "./render/blputil";
import { initI18n, t } from "./i18n";
import { findMapLanguageByName, installReader, loadMapLanguage, localizedMapInfo, setMapLanguage } from "./i18n/mapLanguage";
import { findMapVoiceByName, loadMapVoice, setMapVoice } from "./voice/mapVoice";

// The engine's own UI language (?lang= → remembered → browser), stamped on <html> before the
// first screen exists — the load gate and the menus translate through it (src/i18n/).
initI18n();

// Entry point (plan §6). WebGL scenes, one visible at a time:
//   #menubg — the animated main-menu glue scene (issue #54), behind the FDF menu
//   #bg     — Phase 2 placeholder terrain (WebGL2), the zero-asset fallback
//   #model  — Phase 3 single animated MDX unit (mdx-m3-viewer)
//   #map    — authentic full map + our sim (War3MapViewer)
// Boot shows nothing (an empty black background under the load gate) until the game
// files are imported — the menu's 3D scene is one of those files.
const bgCanvas = document.getElementById("bg") as HTMLCanvasElement;
const menuBgCanvas = document.getElementById("menubg") as HTMLCanvasElement;
const modelCanvas = document.getElementById("model") as HTMLCanvasElement;
// Not `const`: each match gets a canvas of its own, and leaving one replaces this
// (see `freshMapCanvas`).
let mapCanvas = document.getElementById("map") as HTMLCanvasElement;
// The loading screen (issue #78): its art canvas and the layer its DOM goes in. Not part of
// `show()`'s one-at-a-time set — it is up over the top of whichever of those is mid-swap,
// which is the whole point of it — and not inside `#ui`, which a match re-boxes to the
// game frame while this is still on screen (see index.html).
const loadingCanvas = document.getElementById("loading") as HTMLCanvasElement;
const loadingLayer = document.getElementById("loading-layer") as HTMLElement;
const ui = document.getElementById("ui") as HTMLElement;

// The Video panel, before anything can be drawn or loaded (render/videoQuality.ts). It goes
// HERE, at module scope, rather than beside the audio applier down in the gate: texture quality
// is read as a texture is uploaded, so a setting applied after the first viewer exists would
// miss everything that viewer had already loaded.
const bootOptions = loadOptions();
applyVideoOptions(bootOptions);
// The [dbg] console milestones (src/dev/dbg.ts) — debug builds only. Vite folds this to
// `setDbgEnabled(false)` in a build, so the deployed site and the desktop app stay silent.
setDbgEnabled(import.meta.env.DEV);
// …and the Gameplay panel's two health-bar rows (issue #141), which the world overlays read
// live. Here beside the video half so a match started straight off a deep link is already
// wearing the player's committed settings.
applyHealthBarOptions(bootOptions);
// …and the panel's "Hotkeys:" row (issue #142), which the HUD's key handler reads live.
applyHotkeyOptions(bootOptions);
// …and its two scroll sliders, which the camera reads every frame (render/scrollOptions.ts).
applyScrollOptions(bootOptions);
// …and "Voice Control", whose push-to-talk key is only read while it is ticked (src/voice/).
applyVoiceOptions(bootOptions);
// …and the menus' half of it: every glue screen and in-game panel, read off the page when "." is
// held (src/voice/menu.ts).
setMenuVoiceHost(makeMenuVoiceHost());
// The first Voice Control's Vosk model (~70 MB in IndexedDB) is replaced by Whisper's: freed.
forgetOldVoiceModels();

const resolver = new AssetResolver(null);

// Placeholder terrain is now only the zero-asset map fallback, not the menu background — the
// menu uses the real MainMenu3D glue scene once loaded. Built on FIRST USE, never at module load:
// its constructor throws without WebGL2, and a throw up here kills the whole module before the
// load gate mounts — a machine whose GPU is blocklisted (a VM, Xvfb, an old driver) then gets a
// blank window and no word of why, which is how the AppImage catalog's test saw the game
// (AppImage/appimage.github.io#10203).
let terrain: TerrainScene | null = null;
function placeholderTerrain(): TerrainScene {
  if (!terrain) {
    terrain = new TerrainScene(bgCanvas);
    terrain.setTerrain(buildTerrainMesh(makePlaceholderTerrain()));
    terrain.setDoodads([]);
  }
  return terrain;
}

let modelScene: ModelViewerScene | null = null;
let mapScene: MapViewerScene | null = null;
let menuScene: MenuScene | null = null;
let menuDebug: { dispose(): void } | null = null;
// The page's audio. Built once the archives are mounted (every sound is read out of them)
// and handed on to the match, so the menu and the game share one AudioContext.
let sounds: SoundBoard | null = null;
let glueAudio: GlueAudio | null = null;
let meleeConfig: MeleeConfig | null = null; // consumed by the melee initializer (next)
// The LIVE match's end of the wire, held here because the match outlives the screen that
// assembled it and something has to close it when the match ends (docs/multiplayer.md F4).
let matchLink: MatchLinkSetup | null = null;
let installMaps: Map<string, File> = new Map(); // the install's Maps\ folder (Custom Game)
let installFlavour = ""; // which game files are mounted (vfs/loader.ts `flavour`)

// The glue-screen stack (issue #61): main menu → Single Player → Custom Game, each
// leaving and arriving the way the reference does.
const glue = new GlueManager(null);

type Which = "none" | "menubg" | "bg" | "model" | "map";
function show(which: Which): void {
  menuBgCanvas.hidden = which !== "menubg";
  bgCanvas.hidden = which !== "bg";
  modelCanvas.hidden = which !== "model";
  mapCanvas.hidden = which !== "map";
  if (which !== "menubg") menuScene?.stop();
  if (which !== "bg") terrain?.stop();
  if (which !== "model") modelScene?.stop();
  if (which !== "map") mapScene?.stop();
}

/** Show the animated main-menu 3D scene behind the menu (built on first use). Falls
 *  back to an empty background if the glue model is missing/fails to load. */
async function showMenuBackground(vfs: DataSource | null): Promise<void> {
  if (!vfs) { show("none"); return; }
  try {
    if (!menuScene) {
      menuScene = new MenuScene(menuBgCanvas, vfs);
      // The panel chrome's slide carries its own whooshes as SND events keyed into the clip
      // (ui/glueAudio.ts) — play them as they come due.
      menuScene.onSound = (code) => glueAudio?.event(code);
      await menuScene.load();
    }
    show("menubg");
    menuScene.start();
    glueAudio?.start(); // the main-screen theme + the wind under it
    // Opt-in on-screen framing controls (?menudebug) — tune the camera/panel, then
    // "Log values" to print numbers to bake into MenuScene.tuning.
    if (menuScene && !menuDebug && new URLSearchParams(location.search).has("menudebug")) {
      const { mountMenuDebug } = await import("./ui/menuDebug");
      menuDebug = mountMenuDebug(ui, menuScene);
    }
  } catch (err) {
    console.warn("[Warcraft Open] main-menu 3D scene unavailable:", err);
    show("none"); // empty background
  }
}

/** Load a map's bytes into the right scene (authentic with an install, else placeholder).
 *  `campaign` is the `.w3n` a CHAPTER came out of, when it came out of one: its imported art and
 *  the campaign's shared data sit in that archive, underneath the map's own files. */
async function enterMap(bytes: Uint8Array, name: string, campaign?: DataSource): Promise<string> {
  const vfs = resolver.installSource;
  document.body.classList.add("in-game"); // hide the main-menu panel over the map
  if (vfs) {
    show("map");
    if (!mapScene) mapScene = await MapViewerScene.create(mapCanvas, vfs, sounds);
    // A LOAD arrives as a QUEUED save, handed over before the map is read: the scene applies it
    // at the one moment the map's own script has finished initialising (render/mapViewer.ts,
    // `applyQueuedSave`), so the saved world replaces a finished map rather than a half-built one.
    if (pendingLoadSave) {
      mapScene.queueSave(pendingLoadSave);
      pendingLoadSave = null;
    }
    // F10 → End Game, or a Quit button — with the score table when the game it leaves is OVER.
    // …except in a REPLAY WINDOW (src/replayBoot.ts), which has no menu to go back to: leaving
    // the replay closes the window.
    mapScene.onExit = (scores) => (replayBridge() ? replayBridge()!.exit() : exitToMenu(scores));
    // A campaign chapter is completed when its script declares the local player the winner —
    // that, and only that, opens the next one.
    mapScene.onLocalVictory = () => {
      if (pendingCampaign) markMissionComplete(pendingCampaign.key, pendingCampaign.index);
    };
    // …and the chapter's own "and now play THIS": `ChangeLevel`, which the victory dialog's
    // Continue button reaches whenever the map named a next level (see changeLevel below).
    mapScene.onChangeLevel = (path) => void changeLevel(path);
    // …and the defeat dialog's Restart, which plays THIS map again.
    mapScene.onRestart = (difficulty) => void restartMatch(difficulty);
    mapScene.loadMap(bytes, campaign);
    mapScene.start();
    return `${name} — authentic render (textures & models stream in)`;
  }
  show("bg");
  const { terrain: data, doodads } = loadMapBytes(bytes, name);
  const scene = placeholderTerrain();
  scene.setTerrain(buildTerrainMesh(data));
  scene.setDoodads(doodads);
  scene.start();
  return `${name}: placeholder terrain (import an install for authentic assets)`;
}

// --- the glue screens (issue #61) -------------------------------------------------
//
// Each is a GlueScreenDef: which chrome the panel model wears, and how to build the DOM.
// GlueManager runs the transition between them (every button goes disabled → contents fade
// out and the panel slides away → beat → the next panel drops in and its contents fade up),
// all of it timed off the chrome's own Birth/Death clips.

/** Quit the main menu → the launcher. In the desktop app that is a reload: the front page IS the
 *  launcher (src/ui/home.ts), and the folder is remembered by the shell, so the same screen comes
 *  back — with its own Exit Program, which is what really quits. A browser will not let a page
 *  close a tab it did not open, so it reloads onto the site's front page instead. */
function quitToStart(): void {
  if (isDesktopApp()) { location.reload(); return; }
  location.replace(`${location.origin}${location.pathname}`);
}

function mainMenuScreen(vfs: DataSource): GlueScreenDef {
  // The two front ends are different screens, not one screen with a skin: HD wears the 3.0
  // web UI built from the install's own `WebUI\` art (ui/hd/), SD the classic FDF menu.
  if (isHd()) {
    return {
      chrome: "MainMenu",
      noChrome: true,
      mount: async () => {
        const screen = await mountHdMainMenu(ui, vfs, {
          onSinglePlayer: () => void glue.goTo(singlePlayerScreen(vfs)),
          onLan: () => void glue.goTo(lanScreen(vfs)),
          onReplays: () => void glue.goTo(viewReplayScreen(vfs)),
          onOptions: () => void glue.goTo(optionsScreen(vfs)),
          onCredits: () => void startCredits(vfs),
          onQuit: () => quitToStart(),
        });
        void offerReconnect(vfs);
        return screen;
      },
    };
  }
  return {
    chrome: "MainMenu",
    mount: async () => {
      const screen = await mountFdfMainMenu(ui, vfs, {
        onSinglePlayer: () => void glue.goTo(singlePlayerScreen(vfs)),
        onEdition: () => void switchEdition(vfs),
        onLan: () => void glue.goTo(lanScreen(vfs)),
        onOptions: () => void glue.goTo(optionsScreen(vfs)),
        onCredits: () => void startCredits(vfs),
        onQuit: () => quitToStart(),
      });
      void offerReconnect(vfs);
      return screen;
    },
  };
}

/** A reconnect prompt is being asked (or the relay asked whether to put one up) — once at a time. */
let reconnectAsking = false;

/**
 * "Reconnect?" — asked on the MAIN MENU of a player who was thrown out of a LAN game that may
 * still be holding their seat (docs/multiplayer.md "A player who drops"): the game crashed, the
 * window was killed, or the wire would not come back inside the match's own countdown. In a TEAM
 * game the host holds such a seat for the relay's whole hold (server/rooms.mjs HOLD_MS), so there
 * is a game to go back to; the relay is asked first (`probeSeat`) and nothing is shown when it
 * says no — a 1v1 is decided the moment its countdown runs out.
 *
 * Yes loads the map as that client and walks back into the seat once it stands (`startGame`'s
 * `rejoin`). No is a LEAVE, said to the room now (`abandonSeat`) rather than left to the hold —
 * the player's team learns at once that nobody is coming. Asked in the game's own message box,
 * like the update prompt; the words are ours, since the game has no reconnect to word.
 */
async function offerReconnect(vfs: DataSource): Promise<void> {
  if (reconnectAsking || matchLink) return;
  const lobby = new LanLobby(() => new WebSocketTransport());
  const session = lobby.pendingMatch();
  if (!session?.match) return;
  reconnectAsking = true;
  try {
    try {
      await lobby.connect(session.match.url);
    } catch {
      lobby.forgetMatch(); // its relay is gone, and the game with it
      return;
    }
    const leftMs = await lobby.probeSeat();
    if (!leftMs) {
      lobby.forgetMatch();
      lobby.close();
      return;
    }
    const { start, peer, hostPeer } = session.match;
    // The time the relay will still hold the seat, counted down in the prompt itself — the same
    // clock the players still in the match are reading "Time to reconnect" off. At zero the seat
    // is gone, and so is the question.
    const deadline = performance.now() + leftMs;
    const secondsLeft = (): number => Math.max(0, Math.ceil((deadline - performance.now()) / 1000));
    const timeLine = (n: number): string => t("error.reconnectTime", { n });
    const timeParts = t("error.reconnectTime", { n: "\u0000" }).split("\u0000");
    let ticker: ReturnType<typeof setInterval> | null = null;
    const yes = await new Promise<boolean | null>((resolve) => {
      void showGlueDialog({
        container: ui, vfs, buttons: "yesno", dimmed: true,
        text: t("error.reconnectBody", {
          map: start.mapName ?? t("error.aLanGame"),
          time: timeLine(secondsLeft()),
        }),
        onConfirm: () => resolve(true),
        onCancel: () => resolve(false),
      }).then((dialog) => {
        // The FDF painted the message once; the number in it is rewritten where it stands.
        const text = dialog.frame("DialogText");
        ticker = setInterval(() => {
          const n = secondsLeft();
          if (text) {
            const walker = document.createTreeWalker(text, NodeFilter.SHOW_TEXT);
            for (let node = walker.nextNode(); node; node = walker.nextNode()) {
              const raw = node.textContent ?? "";
              const at = raw.indexOf(timeParts[0]);
              if (at < 0) continue;
              const after = raw.slice(at + timeParts[0].length);
              const end = after.indexOf(timeParts[1]);
              if (end < 0) continue;
              node.textContent = raw.slice(0, at) + timeLine(n) + after.slice(end + timeParts[1].length);
            }
          }
          if (n <= 0) {
            dialog.close();
            resolve(null);
          }
        }, 250);
      });
    });
    if (ticker !== null) clearInterval(ticker);
    if (yes === null) {
      lobby.forgetMatch(); // the relay has let the seat go
      lobby.close();
      return;
    }
    if (!yes) {
      lobby.abandonSeat();
      // A beat for the frame to leave before the socket does (as `onShellClosing`).
      setTimeout(() => lobby.close(), 150);
      return;
    }
    // Where the map is HERE — the host's path, or the copy a download left in Maps\Download\.
    const path = localMapPath(installMaps, start.mapPath);
    const info = path ? await readMapInfo(editionMaps(), path, resolver.installSource ?? undefined) : null;
    if (!info) {
      lobby.abandonSeat(); // the map is not in this install any more: there is no way back in
      lobby.close();
      return;
    }
    lobby.handOff();
    const link = matchLinkFrom(lobby, false, start.slots, peer, hostPeer, observerSeats(start));
    void startGame(mapFileFor(path!), info, toConfig(start, peer, startsExplored(info.classification.flags)), link, lobby, path!);
  } finally {
    reconnectAsking = false;
  }
}

/**
 * The main menu's edition button: Reign of Chaos ↔ The Frozen Throne (docs/editions.md).
 *
 * The whole menu fades to black as it stands; under the black the edition flips — which re-points
 * every object table (src/vfs/edition.ts) and every versioned war3skins key — the 3D scene, both
 * panel models and the logo are reloaded as the other edition's, the glue theme and wind swap, and
 * everything this module remembered about the other edition's campaigns is dropped. The new main
 * menu then arrives on its own chrome Birth as the black lifts.
 */
async function switchEdition(vfs: DataSource): Promise<void> {
  await glue.crossWorlds(async () => {
    setEdition(isRoc() ? "tft" : "roc");
    campaigns = [];
    campaignState = null;
    await menuScene?.reloadEdition();
    glueAudio?.swapEdition();
  }, mainMenuScreen(vfs));
}

/** The install's maps the current edition can open. A Reign of Chaos client never could read a
 *  `.w3x` — that extension IS the expansion's map format — so its lists offer the `.w3m`s only. */
function editionMaps(): Map<string, File> {
  if (!isRoc()) return installMaps;
  return new Map([...installMaps].filter(([path]) => !/\.w3x$/i.test(path)));
}

/** The Options screen (issue #81), built from the game's own OptionsMenu.fdf. Its chrome is
 *  the panel model's own "Options" sequence triple. OK/Cancel both return to the main menu;
 *  the live SoundBoard is handed in so the Sound panel is audible as it's dragged. */
function optionsScreen(vfs: DataSource): { chrome: "Options"; noChrome?: boolean; mount: () => Promise<FdfScreen> } {
  if (isHd()) {
    return {
      chrome: "Options",
      noChrome: true,
      mount: () => mountHdOptions(ui, vfs, {
        sounds,
        onClose: () => void glue.goTo(mainMenuScreen(vfs)),
      }),
    };
  }
  return {
    chrome: "Options",
    mount: () => mountOptions(ui, vfs, {
      sounds,
      onClose: () => void glue.goTo(mainMenuScreen(vfs)),
      // Picking a category swings the left-hand settings frame away and back — its Death and
      // its Birth, the same two clips a screen change plays (ui/fdfOptions.ts).
      swapPanel: () => menuScene?.replayPanel("left") ?? { death: 0, birth: 0 },
    }),
  };
}

// --- the LAN screens (issue #77) ---------------------------------------------------
//
// Three screens over ONE relay connection: the game list (LocalMultiplayerJoin.fdf), the
// create screen that picks a map (LocalMultiplayerCreate.fdf), and the game LOBBY every
// player ends up in (GameChatroom.fdf). The connection is held HERE rather than by any of
// them, because it has to survive the transitions between them — and because at Start it is
// handed to the match, which outlives all three (LanLobby.handOff).

/** The live relay connection, and the promise that says whether it came up. Null while we
 *  are nowhere near the LAN screens. */
let lan: { lobby: LanLobby; connected: Promise<void>; stopListening: () => void } | null = null;

// The desktop window closing (Alt+F4, the X, Exit Program) is a CHOSEN departure: say `leave`
// on the way out, or the room hears a dropped connection and stops behind "Waiting for
// players..." for a player who is not coming back (docs/multiplayer.md "A player who drops").
// The match's wire if there is one, else the LAN screens'; then a beat for the frame to leave
// before the shell is told it may close the window.
onShellClosing(async () => {
  const wire = matchLink?.channel ?? lan?.lobby;
  if (!wire) return;
  wire.close?.();
  await new Promise((resolve) => setTimeout(resolve, 150));
});

function lanSession(): { lobby: LanLobby; connected: Promise<void> } {
  if (!lan) {
    const lobby = new LanLobby(() => new WebSocketTransport());
    // A joiner without our map is sent it (net/mapTransfer.ts) — out of the install's own list,
    // asked at the moment of the request, so it is whatever the room is hosting right then.
    lobby.mapSource = (path) => installMaps.get(path) ?? null;
    // Swallowed here so an unhandled rejection is never logged twice; each screen attaches
    // its own `catch` to put the reason on screen.
    const connected = lobby.connect();
    connected.catch(() => {});
    // What the desktop app can HEAR on the subnet (electron/beacon.mjs) goes straight into the
    // same set of watched machines an address typed by hand goes into — discovery adds an
    // ADDRESS and nothing else, which is what keeps it a small feature rather than a second way
    // to learn about games. A no-op in a browser, which cannot hear anything.
    const stopListening = onServersFound((urls) => lobby.setDiscovered(urls));
    // The Warcraft Open servers (src/net/officialServer.ts): on every Servers List out of the box, and
    // removable from none. Watched like any other address, so their games merge into the one
    // list — EU first, which is what makes it the Create Game screen's default.
    for (const official of officialServerAddresses()) {
      try { lobby.addRelay(official, "official"); } catch { /* a malformed override: no official row */ }
    }
    // Reachable for the same reason `warcraft-open.vfs` and `warcraft-open.mapScene` are: the LAN screens
    // are driven headlessly, and "what does the lobby actually think" is the question every
    // harness ends up asking.
    ((window as unknown as { warcraftOpen: Record<string, unknown> }).warcraftOpen ??= {}).lan = lobby;
    lan = { lobby, connected, stopListening };
  }
  return lan;
}

/** The official servers' addresses for THIS build: `VITE_OFFICIAL_SERVER` when the build sets it
 *  — to other servers (comma-separated), or empty to watch none — and the shipped ones otherwise. */
function officialServerAddresses(): string[] {
  const configured = (import.meta.env as Record<string, string | undefined>).VITE_OFFICIAL_SERVER;
  if (configured === undefined) return OFFICIAL_SERVERS.map((s) => s.address);
  return configured.split(",").map((a) => a.trim()).filter((a) => a !== "");
}

/** Leaving the LAN flow entirely (Cancel back to the main menu). A hand-off to a match has
 *  already made `dispose` a no-op, which is the point — see LanLobby.handedToMatch. */
function endLanSession(): void {
  lan?.stopListening();
  lan?.lobby.dispose();
  lan = null;
}

/** Multiplayer (the game's Local Area Network): the relay-backed game list (src/net/, docs/multiplayer.md).
 *
 *  Chrome `BattlenetCustom` — read out of the panel model's own sequence table. The game
 *  has no LAN-specific chrome: LocalMultiplayerJoin.fdf is the transport-swapped twin of
 *  BattleNetCustomJoinPanel.fdf and they share this triple (see menuScene.ts). */
function lanScreen(vfs: DataSource): {
  chrome: "BattlenetCustom";
  noChrome?: boolean;
  mount: () => Promise<FdfScreen>;
} {
  if (isHd()) {
    return {
      chrome: "BattlenetCustom",
      noChrome: true,
      mount: () => {
        const { lobby, connected } = lanSession();
        return mountHdLanScreen(ui, vfs, editionMaps(), lobby, connected, {
          onCancel: () => { endLanSession(); void glue.goTo(mainMenuScreen(vfs)); },
          onCreateGame: () => void glue.goTo(lanCreateScreen(vfs)),
          onJoined: (path, info) => void glue.goTo(lanLobbyScreen(vfs, { path, info })),
          onMapDownloaded: (path, file) => { installMaps.set(path, file); },
        });
      },
    };
  }
  return {
    chrome: "BattlenetCustom",
    mount: () => {
      const { lobby, connected } = lanSession();
      return mountLanScreen(ui, vfs, editionMaps(), lobby, connected, {
        onCancel: () => { endLanSession(); void glue.goTo(mainMenuScreen(vfs)); },
        onCreateGame: () => void glue.goTo(lanCreateScreen(vfs)),
        // The relay confirmed a join: everyone in a room sits in the lobby, host or not.
        onJoined: (path, info) => void glue.goTo(lanLobbyScreen(vfs, { path, info })),
        // A map the host handed us is a map of the install from now on — the Custom Game list
        // has it, and the next game on it needs no download (assets/downloadedMaps.ts).
        onMapDownloaded: (path, file) => { installMaps.set(path, file); },
      });
    },
  };
}

/** "Create Game" on the LAN screen: pick the map to host, then announce the room and drop
 *  into the lobby — which is where the real client puts the host too. */
function lanCreateScreen(vfs: DataSource): {
  chrome: "BattlenetCustom";
  noChrome?: boolean;
  mount: () => Promise<FdfScreen>;
} {
  const onCreate = (
    path: string,
    info: MapInfo,
    gameName: string,
    advanced: AdvancedOptions,
    server: string,
  ): void => {
    const { lobby, connected } = lanSession();
    // The room is as big as the lobby: the map's slots, plus the Observers bench when the
    // host opened one — the relay caps joins at this, so it has to count the bench.
    const seats = info.slots.length + observerSlots(info.slots.length, advanced);
    const announce = (): void => {
      lobby.host(gameName, savedPlayerName(), info.name, path, seats, advanced.observers === "FULL_OBSERVERS", server, advanced.gameSpeed);
    };
    if (server) {
      // A watched SERVER is answering already — the Server menu offers no other kind — so the
      // room goes up on it at once. It throws only if that server dropped in the instant since
      // the menu was painted, and then there is no lobby to go to.
      try { announce(); } catch { return; }
    } else {
      // This machine's own relay may still be connecting: WAIT for the socket, since a
      // `LanLobby` with no transport yet drops a send on the floor without a word.
      void connected.then(announce).catch(() => {}); // the failure is already on screen, on the list we came from
    }
    void glue.goTo(lanLobbyScreen(vfs, { path, info }, advanced));
  };
  if (isHd()) {
    return {
      chrome: "BattlenetCustom",
      noChrome: true,
      mount: () => mountHdLanCreateScreen(ui, vfs, editionMaps(), lanSession().lobby, {
        onCreate,
        onCancel: () => void glue.goTo(lanScreen(vfs)),
      }),
    };
  }
  return {
    chrome: "BattlenetCustom",
    mount: () => mountLanCreateScreen(ui, vfs, editionMaps(), lanSession().lobby, {
      onCreate,
      onCancel: () => void glue.goTo(lanScreen(vfs)),
    }),
  };
}

/** The game lobby — UI\FrameDef\Glue\GameChatroom.fdf, one row per player slot, with the
 *  chat area under it. Its chrome is the panel model's own "MultiplayerPreGameChat" triple. */
function lanLobbyScreen(
  vfs: DataSource,
  map: { path: string; info: MapInfo },
  /** The HOST's Advanced Options, straight off the create screen. A joiner passes none — it
   *  renders whatever the host broadcasts. */
  advanced?: AdvancedOptions,
): {
  chrome: "MultiplayerPreGameChat";
  noChrome?: boolean;
  mount: () => Promise<FdfScreen>;
} {
  const handlers = {
    onCancel: () => void glue.goTo(lanScreen(vfs)),
    onStart: (path: string, info: MapInfo, config: MeleeConfig, link: Parameters<typeof startGame>[3]) =>
      void startGame(mapFileFor(path), info, config, link, undefined, path),
    onCountdownTick: () => glueAudio?.countdownTick(),
  };
  if (isHd()) {
    return {
      chrome: "MultiplayerPreGameChat",
      noChrome: true,
      mount: () => mountHdLanLobbyScreen(ui, vfs, editionMaps(), lanSession().lobby, map, handlers, advanced),
    };
  }
  return {
    chrome: "MultiplayerPreGameChat",
    mount: () => mountLanLobbyScreen(ui, vfs, editionMaps(), lanSession().lobby, map, handlers, advanced),
  };
}

/** The install's own file for a map path — every client opens the map out of its own
 *  install, so a LAN start carries the path and each side resolves it here. */
function mapFileFor(path: string): File {
  const file = installMaps.get(path);
  if (!file) throw new Error(t("error.noSuchMap", { path }));
  return file;
}

function singlePlayerScreen(vfs: DataSource): GlueScreenDef {
  if (isHd()) {
    return {
      chrome: "SinglePlayer",
      noChrome: true,
      // The default hand comes back HERE rather than when Back was clicked — under the black,
      // with the campaign screen already gone (GlueScreenDef.onArrived).
      onArrived: () => applyMenuCursor(vfs),
      mount: () => mountHdSinglePlayer(ui, vfs, {
        onCampaign: () => void openCampaignScreen(vfs),
        onCustomCampaign: () => void glue.goTo(customCampaignScreen(vfs)),
        onViewReplay: () => void glue.goTo(viewReplayScreen(vfs)),
        onCustomGame: () => void glue.goTo(skirmishScreen(vfs)),
        onCancel: () => void glue.goTo(mainMenuScreen(vfs)),
      }),
    };
  }
  return {
    chrome: "SinglePlayer",
    // Its two halves ride separate clips, and which ones depends on whether the player has a
    // profile yet (issue #80 — ui/fdfSinglePlayerMenu.ts).
    sides: singlePlayerSides,
    // The default hand comes back HERE rather than when Back was clicked — under the black, with
    // the campaign screen already gone (GlueScreenDef.onArrived).
    onArrived: () => applyMenuCursor(vfs),
    mount: () => mountSinglePlayerMenu(ui, vfs, {
      onCampaign: () => void openCampaignScreen(vfs),
      onCustomCampaign: () => void glue.goTo(customCampaignScreen(vfs)),
      onViewReplay: () => void glue.goTo(viewReplayScreen(vfs)),
      onCustomGame: () => void glue.goTo(skirmishScreen(vfs)),
      onCancel: () => void glue.goTo(mainMenuScreen(vfs)),
      movePanel: (side, play, wearing) => menuScene?.sidePanel(side, play, wearing) ?? 0,
    }),
  };
}

/** The Custom Campaign and View Replay screens — the two file-list screens hanging off Single
 *  Player. Both wear the "BattlenetCustomCreate" chrome: the panel models carry no triple of
 *  their own, and that is the set whose single tall left-hand frame is the shape these two
 *  files are authored for (see ui/fdfCustomCampaign.ts for the full reasoning). */
function customCampaignScreen(vfs: DataSource): GlueScreenDef {
  if (isHd()) {
    return {
      chrome: "BattlenetCustomCreate",
      noChrome: true,
      mount: () => mountHdCustomCampaign(ui, vfs, {
        onCancel: () => void glue.goTo(singlePlayerScreen(vfs)),
      }),
    };
  }
  return {
    chrome: "BattlenetCustomCreate",
    mount: () => mountCustomCampaignScreen(ui, vfs, {
      onCancel: () => void glue.goTo(singlePlayerScreen(vfs)),
    }),
  };
}

function viewReplayScreen(vfs: DataSource): GlueScreenDef {
  if (isHd()) {
    return {
      chrome: "BattlenetCustomCreate",
      noChrome: true,
      mount: () => mountHdViewReplay(ui, vfs, installMaps, replaySink(), {
        onCancel: () => void glue.goTo(singlePlayerScreen(vfs)),
        onView: (name) => void watchReplayFile(name),
      }),
    };
  }
  return {
    chrome: "BattlenetCustomCreate",
    mount: () => mountViewReplayScreen(ui, vfs, installMaps, replaySink(), {
      onCancel: () => void glue.goTo(singlePlayerScreen(vfs)),
      onView: (name) => void watchReplayFile(name),
    }),
  };
}

// --- the Campaign screens (issue #101) ---------------------------------------------
//
// One screen in two modes — pick a campaign, then pick a chapter of it — over a full-screen
// 3D backdrop instead of the panel chrome every other glue screen wears (ui/fdfCampaign.ts,
// and MenuScene.showBackdrop for the scene half). The campaign index is read once and kept:
// it is one small text file, and both modes and every backdrop swap are views of it.

let campaigns: Campaign[] = [];
/** Which campaign the Campaign screen is on, and which of its two modes. Survives the trips
 *  into a mission and back, so returning lands on the chapter list you left. */
let campaignState: CampaignScreenState | null = null;

/** Open the Campaign screen — on the chapter list of the campaign the player last touched,
 *  else on the campaign list. */
async function openCampaignScreen(vfs: DataSource): Promise<void> {
  if (!campaigns.length) campaigns = await loadCampaigns(vfs);
  if (!campaigns.length) {
    // An install that ships neither edition's index (data/campaigns.ts `loadCampaigns`).
    console.warn("[Warcraft Open] no campaign index for this edition in this install — Campaign unavailable");
    return;
  }
  campaignState ??= { campaign: campaigns[0], chapters: false, difficulty: loadDifficulty() };
  // The screen remembers the campaign across a trip into a mission, but the PROFILE it was
  // remembered under can have changed underneath it (ui/fdfSinglePlayerMenu.ts) — and a
  // campaign the profile in play has not opened is one it may not even see
  // (data/campaignProgress.ts). Fall back to the first, which is always open.
  const at = campaigns.indexOf(campaignState.campaign);
  if (at < 0 || !isCampaignOpen(campaigns, at)) {
    campaignState = { campaign: campaigns[0], chapters: false, difficulty: loadDifficulty() };
  }
  await glue.goTo(campaignScreen(vfs));
}

function campaignScreen(vfs: DataSource): GlueScreenDef {
  const state = campaignState!;
  // The chapter list's behaviour is the same whichever front end draws it: picking a campaign
  // opens its chapters, a chapter starts the map, Back walks out one level, and the difficulty
  // is remembered per profile.
  const handlers = {
    onSelectCampaign: (c: Campaign): void => {
      state.campaign = c;
      state.chapters = true;
      void glue.goTo(campaignScreen(vfs)); // the backdrop changes with the campaign
    },
    onPlayMission: (c: Campaign, index: number): void => void startCampaignMission(vfs, c, index, state.difficulty),
    onBack: (): void => {
      if (state.chapters) { state.chapters = false; void glue.goTo(campaignScreen(vfs)); return; }
      leaveCampaignScreen();
      void glue.goTo(singlePlayerScreen(vfs));
    },
    onDifficulty: (d: Difficulty): void => saveDifficulty(d),
  };
  if (isHd()) {
    return {
      chrome: "SinglePlayer",
      noChrome: true,
      onArrived: () => applyMenuCursor(vfs, state.campaign.cursor),
      mount: () => {
        setCampaignAmbience(state.campaign);
        return mountHdCampaign(ui, vfs, campaigns, state, handlers);
      },
    };
  }
  return {
    // No chrome: the panel models carry no Campaign sequence triple, because the reference
    // hides the screen edges here entirely. `chrome` is unread while `backdrop` is set.
    chrome: "SinglePlayer",
    backdrop: state.campaign.background
      ? { path: state.campaign.background, fog: state.campaign.fog }
      : undefined,
    // The campaign's own racial cursor, put on under the black once the backdrop is up — not
    // while the player is still looking at the screen they are leaving (see onArrived).
    onArrived: () => applyMenuCursor(vfs, state.campaign.cursor),
    mount: () => {
      setCampaignAmbience(state.campaign);
      return mountCampaignScreen(ui, vfs, campaigns, state, handlers);
    },
  };
}

/** The loop under the campaign screen: the campaign's own `AmbientSound` row, in place of the
 *  main menu's wind. Both are AmbienceSounds.slk keys, so this is a swap, not a new channel. */
function setCampaignAmbience(c: Campaign): void {
  if (campaignAmbience && campaignAmbience !== c.ambientSound) sounds?.setAmbienceLoop(campaignAmbience, false);
  if (c.ambientSound) {
    glueAudio?.stopAmbience(); // the main screen's wind gives way to the campaign's
    sounds?.setAmbienceLoop(c.ambientSound, true);
  }
  campaignAmbience = c.ambientSound;
}
let campaignAmbience: string | null = null;

/** Leaving the Campaign screen: the main menu's wind comes back. The CURSOR is not restored
 *  here — a glue screen puts its own on when it arrives (GlueScreenDef.onArrived), so doing it
 *  at the click would change the pointer while the campaign screen is still on display. The one
 *  path with no glue screen to arrive at is a chapter start, which resets it itself. */
function leaveCampaignScreen(): void {
  if (campaignAmbience) sounds?.setAmbienceLoop(campaignAmbience, false);
  campaignAmbience = null;
  glueAudio?.startAmbience();
}

/** Play a chapter. Campaign maps live INSIDE the mounted install (Maps\FrozenThrone\Campaign\*.w3x
 *  in War3x/War3xLocal on an MPQ install, exploded into the content store on 1.30 — see vfs/mapArchive.ts),
 *  not in the install's `Maps\` folder the Custom Game screen browses, so the bytes come from the
 *  VFS. Everything after that is the ordinary custom-map path: the map is not melee-flagged, so
 *  its own triggers set the mission up — which is the point of the campaign as a test bed, since
 *  these maps are where WC3's cinematics actually live. */
async function startCampaignMission(vfs: DataSource, c: Campaign, index: number, difficulty: Difficulty): Promise<void> {
  const mission = c.missions[index];
  // A chapter the campaign's own `.w3n` holds is read from THAT archive: the index names an
  // encrypted `.w3xd` (below), which is the same chapter only the client cannot open.
  const archived = mission ? c.archive?.find(mission.file) ?? null : null;
  // A 3.0 DLC chapter is an encrypted `.w3xd` container (data/campaigns.ts) — the screen
  // disables it, and the `?dev&chapter=` door lands here, where the refusal is stated instead
  // of reading random bytes as a map.
  if (!archived && mission?.encrypted) {
    console.error(`[campaign] ${mission.file} is an encrypted 3.0 DLC chapter; this engine has no reader for .w3xd`);
    void showGlueDialog({ container: ui, vfs, buttons: "ok", text: t("campaign.encrypted") });
    return;
  }
  const bytes = archived && c.archive
    ? await c.archive.read(archived)
    : mission ? await readMapBytes(vfs, mission.file) : null;
  if (!bytes) {
    console.warn(`[Warcraft Open] campaign map missing from this install: ${mission?.file}`);
    return;
  }
  leaveCampaignScreen();
  applyMenuCursor(vfs); // no glue screen arrives after this one — see leaveCampaignScreen
  const info = parseMapInfo(bytes, mission.name);
  // The mission is finished the moment its own script declares victory — that is what opens
  // the next chapter (data/campaignProgress.ts).
  pendingCampaign = { key: c.key, index };
  await startGame(
    bytes, info, campaignConfig(info, difficulty, mission.name), undefined, undefined, mission.file,
    archived ? c.archive?.vfs : undefined,
  );
}

/**
 * `ChangeLevel("Maps\Campaign\Human02.w3m")` — the chapter that just ended asked for the next
 * one, which is what the victory dialog's **Continue** button does in a campaign (see
 * `Runtime.changeLevel` for the Blizzard.j branch it comes out of).
 *
 * The match is taken down exactly as End Game takes it down, and the named map is then started
 * on the campaign's own config — the same path `startCampaignMission` takes, because a chapter
 * reached this way is a chapter reached any other way.
 *
 * The path is looked up in the CAMPAIGN INDEX first, and that lookup is worth more than it
 * looks: it is what gives the loading screen its "Chapter Two / Blackrock & Roll" (a campaign
 * map's own w3i name is the file's), what keeps the chapter list behind the player in step, and
 * what credits the NEXT chapter's victory to the next chapter rather than to this one. A map
 * the index does not name — a custom campaign, a chapter chain we have no row for — still
 * plays: it simply arrives with the map's own name and finishes nothing.
 *
 * A path the install has no map for ends the campaign the only way left: back to the menus,
 * with the chapter that was just won already recorded.
 */
async function changeLevel(mapPath: string): Promise<void> {
  const vfs = resolver.installSource;
  if (!vfs) return exitToMenu();
  // A chapter of a downloaded `.w3n` names its successor by BARE file name (`SetNextLevelBJ
  // ("UndeadRE02.w3x")`), and those maps live inside the campaign archive — never in the
  // install's Maps\ folder. So the campaign that is running is asked first, then the install.
  const playing = pendingCampaign ? campaigns.find((c) => c.key === pendingCampaign!.key) : undefined;
  const archived = playing?.archive?.find(mapPath) ?? null;
  const bytes = archived && playing?.archive ? await playing.archive.read(archived) : await readMapBytes(vfs, mapPath);
  if (!bytes) {
    console.warn(`[Warcraft Open] next chapter missing from this install: ${mapPath}`);
    return exitToMenu();
  }
  const found = findChapter(mapPath);
  const difficulty = campaignState?.difficulty ?? loadDifficulty();
  endMatch();
  if (found) {
    // The campaign screen follows the player: quitting out of chapter two must land on
    // chapter two's list, not on the one the session happened to start from.
    campaignState = { campaign: found.campaign, chapters: true, difficulty };
    pendingCampaign = { key: found.campaign.key, index: found.index };
  } else if (archived && playing) {
    // A place INSIDE a chapter — `UndeadRE02_01.w3x`, one of a chapter's own set-pieces. The
    // index names chapters, not the maps within one, so the chapter stays the one that is
    // running: its victory still finishes that row, and quitting still lands on its list.
    campaignState = { campaign: playing, chapters: true, difficulty };
  } else {
    pendingCampaign = null;
  }
  const title = found?.entry.name ?? mapPath.replace(/^.*[\\/]/, "").replace(/\.w3[mx]$/i, "");
  const info = parseMapInfo(bytes, title);
  await startGame(bytes, info, campaignConfig(info, difficulty, title), undefined, undefined, mapPath, playing?.archive?.vfs);
}

/**
 * Open a SAVE GAME (game/saveFile.ts). The map the save names is read again — out of the same
 * campaign archive it came from, or out of the install — and the save's world is handed to the
 * scene to apply once that map's script has initialised (see `pendingLoadSave` and
 * `MapViewerScene.applyQueuedSave`).
 *
 * The match's own configuration travels in the save, so the seats, the fog mode and the seed
 * are the ones the save was taken with. The seed matters most: without it the sim's dice restart
 * from zero and a loaded game diverges the moment anything is rolled.
 */
async function startSaveGame(game: LiveSave): Promise<void> {
  const vfs = resolver.installSource;
  if (!vfs) return;
  const ref = game.campaign;
  const campaign = ref ? campaigns.find((c) => c.key === ref.key) : undefined;
  const mission = campaign && ref ? campaign.missions[ref.chapter] : undefined;
  const archived = campaign?.archive?.find(mission?.file ?? "") ?? null;
  const bytes = archived && campaign?.archive
    ? await campaign.archive.read(archived)
    : await readMapBytes(vfs, game.map.path);
  if (!bytes) {
    console.warn(`[save] the map this save names is missing from this install: ${game.map.path}`);
    void showGlueDialog({ container: ui, vfs, buttons: "ok", text: t("hd.saveMapMissing") });
    return;
  }
  endMatch();
  campaignState = campaign && ref ? { campaign, chapters: true, difficulty: game.difficulty } : null;
  pendingCampaign = campaign && ref ? { key: campaign.key, index: ref.chapter } : null;
  pendingLoadSave = { world: game.world, script: game.script };
  const info = parseMapInfo(bytes, game.map.name);
  await startGame(bytes, info, game.config, undefined, undefined, game.map.path, campaign?.archive?.vfs);
}

/**
 * `RestartGame` — the defeat dialog's **Restart**, and its **Reduce Difficulty**.
 *
 * Blizzard.j makes them one thing: `CustomDefeatRestartBJ` is `PauseGame(false)` +
 * `RestartGame(true)`, and `CustomDefeatReduceDifficultyBJ` is the same pair with one
 * `SetGameDifficulty` a rung lower in front of it. So the only thing that travels from the old
 * match to the new one is the DIFFICULTY the script left it on — everything else about the
 * lobby is what it was, because it is the same mission being played again.
 *
 * `pendingCampaign` is deliberately untouched: this is the same chapter, so a player who then
 * quits still lands on its own chapter list, and a victory still credits the right row. The
 * chapter's own progress is not disturbed either — losing a mission never cost you the one
 * before it.
 *
 * The SEED is fresh, because this is a new game of the map rather than a rewind: WC3's Restart
 * re-rolls its creep drops and its item stock the same way starting the chapter again does.
 *
 * Refused outright with a wire attached. Blizzard gates the Restart button itself on
 * `bj_isSinglePlayer` and never offers it in a multiplayer game; a map that calls the native
 * anyway cannot be allowed to restart a match other machines are in, so it leaves instead.
 */
async function restartMatch(difficulty: number): Promise<void> {
  const m = lastMatch;
  if (!m || matchLink) return exitToMenu();
  endMatch();
  // The LIVE difficulty is whatever the script left it on; the DEFAULT is the campaign
  // screen's and does not move — "bump the difficulty back up to the default" only means
  // anything if a concession cannot become the default (MeleeConfig.defaultDifficulty).
  await startGame(m.bytes, m.info, {
    ...m.config,
    difficulty,
    defaultDifficulty: m.config.defaultDifficulty ?? m.config.difficulty,
    seed: 1 + Math.floor(Math.random() * 2147483645),
  }, undefined, undefined, m.mapPath, m.campaignSource);
}

/**
 * Go BACK in a replay (issue #158): play it again from its start and race to step `at`, with
 * what the watcher had set carried over (MapViewerScene.onReplayRewind). A match only runs
 * forward, so this is the only way back until the world can be snapshotted mid-match.
 */
async function rewindReplay(at: number, view: ReplayView): Promise<void> {
  const m = lastMatch;
  if (!m?.config.replay) return;
  endMatch();
  await startGame(m.bytes, m.info, { ...m.config, replayResume: { at, ...view } }, undefined, undefined, m.mapPath);
}

/** The match on screen, kept so `RestartGame` can play it again. */
let lastMatch: { bytes: Uint8Array; info: MapInfo; config: MeleeConfig; mapPath?: string; campaignSource?: DataSource } | null = null;

/** A save on its way into `enterMap`: set by `startSaveGame`, consumed there. */
let pendingLoadSave: { world: WorldSnapshot; script: SaveScript | null } | null = null;

/**
 * The save screens' door to the running match (game/saveManager.ts — the seam that keeps the
 * screens from importing this file). Captured lazily: a menu has no world to save, and a fresh
 * match's `lastMatch` is only set once its bytes are in hand.
 */
setSaveHost({
  capture: () => mapScene?.captureSave() ?? null,
  seat: () => {
    const m = lastMatch;
    if (!m) return null;
    return {
      map: { path: m.mapPath ?? m.info.name ?? "", name: m.info.name ?? m.mapPath ?? "" },
      campaign: pendingCampaign ? { key: pendingCampaign.key, chapter: pendingCampaign.index } : null,
      config: m.config,
      localPlayer: mapScene?.seatPlayer ?? 0,
      // The chapter screen's rung, which is what a load restores; a melee match has none and
      // takes the profile's default, exactly as starting one from the menu would.
      difficulty: campaignState?.difficulty ?? loadDifficulty(),
    };
  },
  load: (game) => startSaveGame(game),
  engine: () => gameVersion() ?? "unknown",
});

/** Which campaign row a `Maps\…\Foo.w3x` path is, if the index names it. Compared on the
 *  path the index itself carries — case- and separator-insensitively, because a script types
 *  the path by hand (`SetNextLevelBJ`) and nothing makes it match the file's own spelling. */
function findChapter(mapPath: string): { campaign: Campaign; index: number; entry: CampaignEntry } | null {
  const key = (p: string): string => p.toLowerCase().replace(/\//g, "\\");
  const want = key(mapPath);
  for (const c of campaigns) {
    const index = c.missions.findIndex((m) => key(m.file) === want);
    if (index >= 0) return { campaign: c, index, entry: c.missions[index] };
  }
  return null;
}

/**
 * The main menu's Credits button (`creditsMap`, data/campaigns.ts).
 *
 * WC3's credits are a MAP and nothing else — there is no credits screen to build — so this is
 * the chapter path with the campaign taken out of it: the edition's credits map out of the
 * archives, on `campaignConfig`, and the match's own script rolls the names. Everything that
 * makes a CHAPTER a chapter is deliberately absent: `pendingCampaign` is cleared, because
 * watching the credits finishes nothing and a victory the map's own script declares must not
 * be credited to whatever chapter was last played.
 *
 * Difficulty is Normal, and it is not a choice withheld: no screen offers one here, and the
 * map asks nothing of `GetGameDifficulty`.
 */
async function startCredits(vfs: DataSource): Promise<void> {
  const path = creditsMap();
  const bytes = await readMapBytes(vfs, path);
  if (!bytes) {
    console.warn(`[Warcraft Open] credits map missing from this install: ${path}`);
    return;
  }
  applyMenuCursor(vfs); // no glue screen arrives after this one — the match does
  const info = parseMapInfo(bytes, "Credits");
  pendingCampaign = null;
  await startGame(bytes, info, campaignConfig(info, "normal", info.name || "Credits"), undefined, undefined, path);
}

/** The chapter the player is IN, so a victory can be credited to it. */
let pendingCampaign: { key: string; index: number } | null = null;

/** The `?dev&chapter=` boot (src/dev/devBoot.ts): start the campaign chapter whose map path
 *  contains `name`, straight out of the mounted archives and on the campaign's own config.
 *  The chapters are where the cinematics and the scripted set-pieces are, and there is no
 *  other way for automation to reach one — the campaign screen needs a human. */
async function startChapter(name: string, difficulty: string): Promise<void> {
  const vfs = resolver.installSource;
  if (!vfs) throw new Error("no install mounted");
  // Into the MODULE's list, not a local one: a chapter that ends with `ChangeLevel` looks the
  // next map up in exactly this index (`findChapter`), so a dev boot that kept the campaigns
  // to itself would play chapter one and then hand chapter two over as a nameless map.
  if (!campaigns.length) campaigns = await loadCampaigns(vfs);
  for (const c of campaigns) {
    const index = c.missions.findIndex((m) => m.playable && m.file.toLowerCase().includes(name.toLowerCase()));
    if (index < 0) continue;
    campaignState ??= { campaign: c, chapters: true, difficulty: difficulty as Difficulty };
    await startCampaignMission(vfs, c, index, difficulty as Difficulty);
    return;
  }
  throw new Error(`no campaign chapter matching "${name}"`);
}

/** A campaign map's lobby config. A campaign is single-player: the local player takes the
 *  first slot the map declares a human, and every other slot stays what the MAP made it —
 *  these maps seat their own AI (and their own neutral-hostile), and the start locations are
 *  the map's. Nothing here is a choice the player was offered EXCEPT the difficulty, because
 *  that is the only one the reference's campaign screen offers — and the map reads it:
 *  Terror of the Tides gates waves on `GetGameDifficulty()`. */
function campaignConfig(info: MapInfo, difficulty: Difficulty, title: string): MeleeConfig {
  const local = Math.max(0, info.slots.findIndex((s) => s.controller === "user"));
  const seat = (s: PlayerSlot | NeutralPlayer, i: number): SlotConfig => ({
    id: s.id,
    controller: i === local ? "user" : s.controller === "user" ? "computer" : s.controller,
    race: s.defaultRace,
    team: s.team,
    startX: s.startX,
    startY: s.startY,
    name: s.name, // the map's own name for the side ("Illidan's Naga"), for the hover tooltip
    // …and, in the seat the player is actually in, who they are: the profile the chapter is
    // being played on (data/profiles.ts `profilePlayerName`), not the LAN screen's typed name.
    ...(i === local ? { playerName: profilePlayerName() } : {}),
  });
  // The map's neutral/rescuable players ride along at the end, keeping the controller the map
  // gave them — they are nobody's AI and nobody's seat, but they own units and the mission
  // names them ("Prisoners", "Night Elf Villagers"). See MapInfo.neutralPlayers.
  const slots: SlotConfig[] = [
    ...info.slots.map(seat),
    ...info.neutralPlayers.map((s) => seat(s, -1)),
  ];
  return {
    slots,
    // A campaign chapter starts BLACK. "explored" is the Custom Game screen's convenience
    // default and was inherited here by accident; no campaign map has ever begun with its
    // terrain handed to you. It matters beyond looks — a chapter's own script is what parts
    // the mask (`CreateFogModifierRect`, `FogMaskEnable`, the cinematic reveals), and Rise of
    // the Naga's intro even wipes the map back to MASKED when the cinematic is skipped, which
    // only makes sense against a map that was never explored to begin with.
    fog: "unexplored",
    // What each force grants — and chapter one's grant "allied, no shared vision" is the whole
    // reason this travels: without it the Watchers, the Villagers and the Prisoners lit their
    // half of the map from the first frame (see MapInfo.ForceGrants).
    forces: info.forces.map((f) => ({ allied: f.allied, sharedVision: f.sharedVision })),
    // The chapter's title, because the map's own w3i name is the file's ("NightElfX01").
    mapName: title,
    seed: 1 + Math.floor(Math.random() * 2147483645),
    difficulty: DIFFICULTY_INDEX[difficulty],
    // A mission, not a game off a list — which is what makes the console's Allies and Chat
    // buttons dead: there is nobody to ally with and nobody to talk to.
    campaign: true,
  };
}

/** The campaign screen's choice as common.j's `gamedifficulty` index — MAP_DIFFICULTY_EASY 0 /
 *  NORMAL 1 / HARD 2 (INSANE 3 exists in common.j but no screen offers it). */
const DIFFICULTY_INDEX: Record<Difficulty, number> = { easy: 0, normal: 1, hard: 2 };

function skirmishScreen(vfs: DataSource): { chrome: "SinglePlayerSkirmish"; noChrome?: boolean; mount: () => Promise<FdfScreen> } {
  if (isHd()) {
    return {
      chrome: "SinglePlayerSkirmish",
      noChrome: true,
      mount: () => mountHdSkirmish(ui, vfs, editionMaps(), {
        onCancel: () => void glue.goTo(singlePlayerScreen(vfs)),
        onStart: (file, info, config, path) => void startGame(file, info, config, undefined, undefined, path),
      }),
    };
  }
  return {
    chrome: "SinglePlayerSkirmish",
    mount: () => mountSkirmish(ui, vfs, editionMaps(), {
      onCancel: () => void glue.goTo(singlePlayerScreen(vfs)),
      onStart: (file, info, config, path) => void startGame(file, info, config, undefined, undefined, path),
    }),
  };
}

/**
 * WATCH a replay (issue #158, game/replay.ts): the match it recorded, on the same map out of
 * this install, played by its file. The map is found by the install path it was recorded on and,
 * failing that (an install laid out differently), by its file name; its bytes' hash says whether
 * it is the SAME map, and a different one is played anyway with a warning — the state checks will
 * say how far it got.
 */
/** View Replay's button: read the file, then watch it (ui/fdfViewReplay.ts). A replay from
 *  another Warcraft Open asks first, with the game's own "Incompatible Replay!" question. */
async function watchReplayFile(name: string): Promise<void> {
  const bytes = await replaySink()?.read(name);
  if (!bytes) return;
  const replay = await decodeReplay(bytes);
  refuseOtherLine(replay);
  await watchReplay(replay);
}

/** A replay from the other data / asset line cannot be played here — SD and HD read different
 *  object tables, and an HD replay also needs the Reforged build it was recorded on. The lists
 *  refuse it before this (ui/fdfViewReplay.ts); this covers the direct doors (a `?replay=` link,
 *  the replay window, LastReplay). */
export function refuseOtherLine(replay: Replay): void {
  const why = replayRefusalText(replay.header, flavor(), gameVersion());
  if (!why) return;
  console.error(`[replay] refused: ${why}`);
  throw new Error(why);
}

async function watchReplay(replay: Replay): Promise<void> {
  const h = replay.header;
  const path = replayMapPath(installMaps, h.map.path);
  const file = path ? installMaps.get(path) : undefined;
  if (!path || !file) throw new Error(`The map "${h.map.name}" is not in this install.`);
  const info = await readMapInfo(installMaps, path);
  if (!info) throw new Error(`The map "${h.map.name}" could not be read.`);
  const hash = fnv64(new Uint8Array(await file.arrayBuffer()));
  if (hash !== h.map.hash) console.warn(`[replay] ${path} is not the map this replay was recorded on (hash ${hash}, recorded ${h.map.hash})`);
  if (h.version !== __OW3_VERSION__) console.warn(`[replay] recorded on Warcraft Open ${h.version}; this is ${__OW3_VERSION__}`);
  // The BALANCE PATCH the match was played on (src/patches/): a replay is a match on those
  // tables. Put back when the replay is left (`exitToMenu`), never remembered.
  if (h.patch && h.patch !== patchLevel()) {
    replayPatchWas ??= patchLevel();
    try {
      setPatchLevel(h.patch);
    } catch (err) {
      console.warn(`[replay] recorded on patch ${h.patch}, which this build does not have:`, err);
    }
  }
  await startGame(file, info, { ...h.config, observer: true, replay }, undefined, undefined, path);
}

/** Leave the menus and play: load the map, then melee or custom setup as the map asks.
 *
 *  The map arrives either as a FILE the player browsed to (the install's `Maps\` folder, which
 *  is what the Custom Game and LAN screens pick from) or as BYTES already read out of the
 *  archives — a campaign chapter lives inside War3x/War3xLocal and never touches the disk. */
async function startGame(
  map: File | Uint8Array,
  info: MapInfo,
  config: MeleeConfig,
  link?: MatchLinkSetup,
  /** Coming BACK into a match already under way, from the main menu's "Reconnect?" — the lobby
   *  whose seat is reclaimed once the map is loaded (`reconnectFromMenu`). */
  rejoin?: LanLobby,
  /** The map's install path, when it has one — where its Chinese language file would sit
   *  (`i18n/mapLanguage.ts`), and what a REPLAY of the match names it by so View Replay can
   *  find it again. Absent for a campaign chapter, which comes out of an archive. */
  mapPath?: string,
  /** The `.w3n` a CHAPTER came out of (data/campaignArchive.ts), layered under the map so the
   *  campaign's imported art and shared object data resolve. Absent for every other match. */
  campaignSource?: DataSource,
): Promise<void> {
  meleeConfig = config;
  matchLink = link ?? null;
  // P4's map door, BEFORE the menus leave and before any table or asset is read: a map from
  // the other game line, or one whose base ids / models this install cannot supply, is refused
  // here with a reason and leaves the player where they were. `MapViewerScene.loadMap` repeats
  // the same check as a backstop for doors that bypass this one (the `?dev` hook).
  const mapBytes = map instanceof Uint8Array ? map : new Uint8Array(await map.arrayBuffer());
  const install = resolver.installSource;
  if (install) {
    const refusal = mapLoadRefusal(mapBytes, install, loadUnitRegistry(install));
    if (refusal) {
      console.error(`[map] refused to load "${info.name}": ${refusal.detail}`);
      // The player's half: the game's own message box, over whatever screen they started from
      // (the row they clicked was greyed and already said this on hover, but a dev link, a
      // replay or a host's map never came through the list). The throw leaves the menus alone.
      void showGlueDialog({ container: ui, vfs: install, buttons: "ok", text: refusal.message });
      throw new Error(refusal.message);
    }
  }
  // WHICH OBJECT TABLES THIS MATCH PLAYS ON, before a byte of the map is read and before any
  // table is parsed. The install keeps four complete sets and the map's own w3i melee flag
  // picks between two of them (src/data/edition.ts, src/vfs/edition.ts): a melee map plays on
  // the latest balance, everything else — a campaign chapter, a scenario, a custom map — on the
  // set frozen where the game shipped. It is what gives a Reign of Chaos campaign Grunt its 680
  // hit points instead of a melee game's 700.
  setMapDataSet(info.isMelee ? "melee" : "custom");
  // A MAP'S OWN CHINESE FILE (i18n/mapLanguage.ts): `<map file name>.zhCN.json` in the map's
  // folder, read before anything shows the map's text — the loading screen already prints its
  // name. Cleared when the map has none, so one map's dictionary never speaks for the next.
  const reader = install ? installReader(install) : null;
  let language = reader && mapPath ? await loadMapLanguage(reader, mapPath) : null;
  // …and if that path does not answer, ask the install for the file BY NAME. A host that hands
  // the map over with a path spelled differently (`Maps\hhkj` / `maps\hhkj`), or with none at
  // all, otherwise loses the sidecar in silence and the match plays in the author's language.
  if (!language && reader && install) {
    const name = map instanceof File ? map.name : info.name;
    if (name) language = await findMapLanguageByName(reader, () => install.list(), name);
  }
  setMapLanguage(language);
  // A MAP'S OWN VOICE PACK (voice/mapVoice.ts): `<map>.voice.json` beside it, read from the
  // PLAYER'S language block. Cleared when the map has none, so one map's words never answer the
  // next. The same by-name fallback as the language file, for a host that spells the folder
  // differently.
  let voice = reader && mapPath ? await loadMapVoice(reader, mapPath) : null;
  if (!voice && reader && install) {
    const voiceName = map instanceof File ? map.name : info.name;
    if (voiceName) voice = await findMapVoiceByName(reader, () => install.list(), voiceName);
  }
  setMapVoice(voice);
  // `warcraft-open.mapVoice` answers "did this map's own voice commands load?".
  ((window as unknown as { warcraftOpen: Record<string, unknown> }).warcraftOpen ??= {}).mapVoice = voice
    ? { live: true, locale: voice.locale, names: voice.pack.entries?.length ?? 0, commands: voice.pack.phrases?.length ?? 0 }
    : { live: false };
  // A one-line answer for the question "why is this map still in its author's language?": type
  // `warcraft-open.mapLanguage` in the console. `live:false` means no dictionary for this map at all
  // (nothing beside it, or the install cannot see it) — which is what the `[i18n]` lines above
  // say in full, and what an empty list of matches means when it says live:true.
  ((window as unknown as { warcraftOpen: Record<string, unknown> }).warcraftOpen ??= {}).mapLanguage = language
    ? {
        live: true, wts: language.wts.size, text: language.text.size,
        abilities: language.objects.abilities.size, items: language.objects.items.size,
        units: language.objects.units.size, upgrades: language.objects.upgrades.size,
      }
    : { live: false };
  if (language) info = localizedMapInfo(info, language);
  // The menus LEAVE the way they always leave (issue #78): the panel's contents fade out and
  // the chrome slides up on its own "<Screen> Death" clip, whooshes and all, and only then
  // does the loading screen appear. Awaited, so the two never overlap — and awaited BEFORE the
  // music is cut, or the departure plays silent. The match owns the screen from here, wire
  // included; the LAN screen handed that over before calling us (LanLobby.handOff).
  await glue.leave();
  glueAudio?.stop(); // …and the music channel: the map's own script cues its music from here

  // The readiness gate goes up FIRST, before a byte is read (src/game/loadGate.ts). A peer on a
  // faster disk finishes while we are still inside `loadMap` — one long synchronous call — and
  // its message lands on whatever `onPeerData` is installed at that moment, which is nothing
  // until the link is attached further down. Installed here, it catches them all.
  // Not for a player coming back: everybody else loaded long ago and is not going to say so again.
  const gate = link && !rejoin ? new LoadGate(link.channel, remotePeers(link)) : null;

  // The LOADING SCREEN (issue #78) goes up before a byte of the map is read and comes down
  // when the match is standing. Every step below is a `step()`, and `step` yields to the
  // browser before running its body — which is not politeness but the whole reason the screen
  // is visible at all: `loadMap` is one long SYNCHRONOUS call, so without a paint between the
  // steps the bar would go up and come down inside a single frame nobody ever saw.
  // (The map's bytes were read ONCE at the top, for the P4 gate: the loading screen reads its
  // art out of the same array, and a `File` a browser handed us may not be readable twice.)
  // The loading screen prints the map's own w3i text, and its TRIGSTR fields resolve through
  // war3map.wts (`world/mapInfo.ts`). `info` above was parsed BEFORE `setMapLanguage` went live,
  // so read the w3i once more now that it has — the loading blurb is the first place a player
  // meets the map's own words, and without this it stayed in the author's language.
  if (language) info = localizedMapInfo(parseMapInfo(mapBytes, info.name), language);
  const loading = await showLoadingScreen(info, config, mapBytes, campaignSource);
  if (gate && loading) {
    gate.onReady = (peer) => loading.setPeerReady(peer);
    // …including anyone who reported while the screen was still being built.
    for (const peer of gate.readyPeers) loading.setPeerReady(peer);
  }
  // NOTHING BEHIND THE SCREEN MAY BE HEARD. The map's script cues its soundtrack from
  // `main()` and every unit it spawns lands with a sound, so the match used to be plainly
  // audible under a picture that still said "L O A D I N G". Held here, released with the
  // screen — the world is held with it (`holdAtStart`, below), so what the player hears and
  // what the player sees begin on the same frame (src/audio/sounds.ts setLoadingGate).
  sounds?.setLoadingGate(true);
  // …and nothing behind it may be OPENED: F11 at the loading screen started the match with
  // the Allies dialog up (MapViewerScene.togglePanel).
  mapScene?.setLoadingScreen(true);
  try {
    const step = async <T>(at: number, body: () => T | Promise<T>): Promise<T> => {
      loading?.setProgress(at);
      await nextFrame();
      return body();
    };

    const bytes = await step(0.05, () => mapBytes);
    // …kept, so the match can be PLAYED AGAIN without going back to the menu: `RestartGame`,
    // the defeat dialog's first button (see restartMatch). The bytes rather than the `File`,
    // because a file handle a browser handed us once may not be readable a second time.
    lastMatch = { bytes, info, config, mapPath, campaignSource };
    // The minimap's markers are read out of the map itself (its terrain header and its placed
    // units), so they can only be stamped once its bytes are in hand — which is why the loading
    // screen takes them afterwards rather than at mount. Never at the cost of the match: a map
    // whose unit list we cannot read still starts, with a bare picture.
    loading?.setMinimapPreview(previewOf(bytes));
    await step(0.15, () => enterMap(bytes, info.name, campaignSource));
    mapScene?.setLoadingScreen(true); // the first match's scene exists only from here
    // What a REPLAY of this match names its map by (issue #158): the install's own path for it
    // when it came off a list, the bytes' hash so the same name is not taken for the same map.
    mapScene?.setReplayMap({
      path: mapPath ?? (map instanceof File ? [...installMaps].find(([, f]) => f === map)?.[0] : undefined) ?? config.mapName ?? info.name,
      name: info.name,
      hash: fnv64(bytes),
      size: bytes.length,
    }, installFlavour);
    // Melee maps get the standard setup (town hall + workers, melee rules);
    // custom/scenario maps run their own triggers instead (see mapKind.ts).
    //
    // Setup is where the bar spends most of its life and it used to spend it PARKED: the long
    // wait inside it is the map's own art streaming in (MapViewerScene.startMelee), and that
    // is exactly the stretch the browser is free to paint through, so a bar with nothing to
    // say sat still for it. It now creeps on the loader's own drain — 0.6 → 0.9 here, the last
    // tenth to the preload, in the ratio the two were measured at on `(2)EchoIsles.w3x`
    // (~1.0 s of streaming against ~0.3 s of preload).
    const setupProgress = (p: number): void => loading?.setProgress(0.6 + 0.3 * p);
    await step(0.6, () => (info.isMelee
      ? mapScene?.startMelee(config, setupProgress)
      : mapScene?.startCustom(config, setupProgress)));
    // …and there the world STOPS, built but not begun, until the screen comes down
    // (MapViewerScene.holdAtStart). Every game, not only a campaign chapter: setup returns
    // seconds before the player is looking at the map, and the creeps, the melee clock and the
    // music used to spend those seconds running behind the loading screen.
    mapScene?.holdAtStart(true);
    // A replay goes back in time by being played again (`rewindReplay`).
    if (config.replay && mapScene) mapScene.onReplayRewind = (at, view) => void rewindReplay(at, view);
    // A LAN match hands over the match's end of the wire (docs/multiplayer.md item 10b-note); a
    // skirmish passes none, and the controller runs exactly as it always has. Attach it AFTER
    // setup so the world it snapshots exists.
    if (link) {
      mapScene?.attachMatchLink(link);
      // v1 has no host migration, so the room closing IS the end of the match — and this message
      // is the only evidence a client gets (docs/multiplayer.md Phase F item 6). Without it the
      // wire simply goes quiet and the client keeps simulating a world nobody owns any more.
      link.channel.onRoomClosed = () => mapScene?.showMatchOver();
      // …and a CLIENT leaving is the departure nothing else reports: the relay's `peer-leave`
      // is the only word of it, and the host is the one machine that must act on it.
      link.channel.onPeerLeave = (peer) => mapScene?.peerLeft(peer);
      // …and a connection that DROPPED rather than left: the match stops behind "Waiting for
      // players..." while the host counts down (docs/multiplayer.md "A player who drops"). The
      // rejoin is chained onto MatchLink's own handler, which owes the returner a catch-up.
      link.channel.onPeerDrop = (peer, holdMs) => mapScene?.peerDropped(peer, holdMs);
      const rejoined = link.channel.onPeerRejoin;
      link.channel.onPeerRejoin = (peer) => {
        rejoined(peer);
        mapScene?.peerRejoined(peer);
      };
      // Our OWN connection, from this end: stop while it re-dials, carry on if it gets back in,
      // and "You were disconnected." if it does not.
      link.channel.onLinkLost = () => mapScene?.linkLost();
      link.channel.onRejoined = () => mapScene?.linkRestored();
      link.channel.onDisconnected = () => mapScene?.showDisconnected();
    }
    // The last stretch of the bar is a REAL load rather than a number climbing on its own: the
    // models and icons the opening minutes will ask for, fetched now instead of hitching the
    // frame each is first wanted on (MapViewerScene.preloadForStart — the job WC3's own
    // `Preload` natives do for a map). It is also what the hold below is spent on.
    const tailStart = performance.now();
    await mapScene?.preloadForStart((p) => loading?.setProgress(0.9 + 0.1 * p));
    // Our bar is full. Tell the room (a LAN match), and hold while any other machine is still
    // loading — their seats light as their messages arrive and the bar's caption becomes the
    // game's own "WAITING FOR OTHER PLAYERS". `waitForAll` gives up after a minute rather than
    // stranding a player whose opponent closed the tab (LOAD_GATE_TIMEOUT_MS).
    loading?.finish();
    if (gate) {
      gate.announce();
      await gate.waitForAll();
    }
    // Back into the seat only NOW, with the world standing: the host answers a returning player
    // with a full snapshot at once (MatchLink `owed`), and a world still loading would drop it.
    // Until it lands the match waits on the host behind "Waiting for host..." (`linkLost`).
    if (rejoin) {
      mapScene?.linkLost();
      rejoin.reclaimSeat();
    }
    // A SINGLE-PLAYER game does not begin on its own. The reference holds the finished screen
    // on `LOADING_PRESS_A_KEY` ("PRESS ANY KEY TO CONTINUE") and starts the match on the
    // player's key — a campaign chapter, whose title and blurb are on that screen to be read,
    // and a Custom Game off the Single Player menu alike. How long that takes is the player's
    // business, and nobody else is waiting on them.
    //
    // `link` is the whole test, and it is the right one: a match with a wire has other machines
    // on the far end of it, and none of them can be held on one player's keyboard. Multiplayer
    // keeps the gate above and the timed beat below.
    // …except a REPLAY, which is watched rather than played, and is played again from its start
    // every time the watcher goes back in time.
    if (!link && loading && !config.replay) await loading.waitForKey();
    else await wait(Math.max(MIN_FULL_BAR_MS, START_HOLD_MS - (performance.now() - tailStart)));
    // Taken away only once the match has actually DRAWN a frame behind it, so the first thing the
    // player sees is the map and never the black canvas it was on a moment ago.
    await nextFrame();
    await nextFrame();
  } finally {
    // The screen goes, and the match begins in the same breath — whatever happened. A load
    // that THREW must not leave a frozen, silent world behind a dead loading screen.
    loading?.dispose();
    loadingCanvas.hidden = true;
    mapScene?.holdAtStart(false);
    mapScene?.setLoadingScreen(false);
    sounds?.setLoadingGate(false);
  }
}

/**
 * How long the tail of a MULTIPLAYER load lasts — the preload, and then a beat on the full bar.
 *
 * OURS, not the game's: the developer asked for it, because a load that ends the instant the
 * bar fills never shows the player the screen they were waiting on. Measured from the START of
 * the preload rather than added after it, so the three seconds are spent LOADING on a cold
 * machine and idling on a warm one — either way the screen is up for the same three seconds
 * and the match begins when it comes down.
 *
 * A single-player load does not use it at all: that screen waits for a key instead, which is
 * the reference's own answer to the same problem and needs no number.
 */
const START_HOLD_MS = 3000;

/** …and the floor under that, so a preload that ate the whole beat still lets the filled bar
 *  be seen rather than flashing full for one frame. */
const MIN_FULL_BAR_MS = 500;

/** A map's gold mines, shops and start locations for the loading screen's minimap. */
function previewOf(bytes: Uint8Array): MapPreview | null {
  const vfs = resolver.installSource;
  if (!vfs) return null;
  try {
    return readMapPreviewBytes(vfs, bytes);
  } catch (err) {
    console.warn("[Warcraft Open] couldn't read the map's minimap markers:", err);
    return null;
  }
}

/** The relay peers of the OTHER machines in this match — everyone the gate waits for. A seat
 *  with no peer is an AI or an empty chair; ours is the seat `localPlayer` names. */
function remotePeers(link: MatchLinkSetup): number[] {
  return link.seats
    .filter((s) => s.peer !== undefined && s.id !== link.localPlayer)
    .map((s) => s.peer as number);
}

/**
 * Put the loading screen up over everything, on its own canvas (ui/loadingScreen.ts).
 *
 * A campaign chapter hands it the campaign INDEX's title lines rather than the map's, for the
 * same reason the quest log's header takes them: `NightElfX01`'s w3i calls itself "NightElfX01"
 * and the screen the player came from calls it "Chapter One — Rise of the Naga".
 */
async function showLoadingScreen(
  info: MapInfo,
  config: MeleeConfig,
  map: Uint8Array,
  campaign?: DataSource,
): Promise<LoadingScreen | null> {
  const install = resolver.installSource;
  if (!install) return null; // the zero-asset fallback has no art to put up
  // The screen reads the MAP's archive before the install's, as every other asset of the match
  // does (render/assetSolver.ts). It is where a map's own loading model lives (the w3i's
  // `loadingScreenModel` — which, read off the install alone, could never be found), and where
  // a map that names no model puts the art it means instead: it imports textures OVER the stock
  // screen's. Bleach vs One Piece ships `UI\Glues\Loading\Multiplayer\Loading-TopLeft.blp` and
  // the rest of the Human race screen's quarters, and the real 1.30.4 client shows its own
  // picture there; read from the install alone, we showed Blizzard's.
  // A campaign chapter inserts its `.w3n` between the two: the campaign's own loading art is
  // there, over the install's, under the chapter's.
  const layers: DataSource[] = [];
  try {
    layers.push(new MpqDataSource("map", map), ...(campaign ? [campaign] : []));
  } catch (err) {
    console.warn("[Warcraft Open] loading screen: map archive unreadable, using the install's art:", err);
  }
  layers.push(install);
  const vfs: DataSource = layers.length === 1 ? install : new LayeredDataSource(layers);
  const chapter = pendingCampaign
    ? campaigns.find((c) => c.key === pendingCampaign?.key)?.missions[pendingCampaign.index]
    : undefined;
  try {
    // Built while still HIDDEN, and revealed only once it resolves — `mountLoadingScreen`
    // decodes its art before it returns, so the menu's last frame gives way to a finished
    // picture instead of to a black canvas that fills in a beat later. The menu's own 3D scene
    // stops in the same breath: it is about to be thrown away, and the load is the one moment
    // the machine has something better to do than draw an invisible seascape.
    const screen = await (isHd() ? mountHdLoadingScreen : mountLoadingScreen)({
      container: loadingLayer, canvas: loadingCanvas, vfs, info, config,
      title: chapter?.header, subtitle: chapter?.name,
    });
    show("none");
    loadingCanvas.hidden = false;
    return screen;
  } catch (err) {
    console.warn("[Warcraft Open] loading screen unavailable:", err);
    loadingCanvas.hidden = true;
    return null;
  }
}

/**
 * Let the browser paint. Every load step is fenced by one of these — see `startGame`.
 *
 * A HIDDEN tab is served no animation frames at all, so a player who alt-tabs while a map is
 * loading would stall the load itself at the next fence and not get it back until they looked
 * again. There is nothing to wait for there — what the fence buys is a chance to PAINT the
 * loading bar, and a hidden tab is painting nothing — so hand the step straight on instead,
 * both when we already know the tab is hidden and if it goes hidden while we are waiting.
 */
function nextFrame(): Promise<void> {
  return new Promise((resolve) => {
    if (document.hidden) return void setTimeout(resolve, 0);
    const onHide = (): void => { if (document.hidden) finish(); };
    let done = false;
    const finish = (): void => {
      if (done) return;
      done = true;
      document.removeEventListener("visibilitychange", onHide);
      resolve();
    };
    document.addEventListener("visibilitychange", onHide);
    requestAnimationFrame(finish);
  });
}

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Enumerable unit models from the mounted install (portraits excluded). */
function listModels(): string[] {
  const vfs = resolver.installSource;
  if (!vfs) return [];
  return vfs
    .list()
    .filter((p) => /^units\\.*\.mdx$/i.test(p) && !/portrait/i.test(p))
    .sort();
}

async function viewModel(path: string): Promise<SequenceInfo[]> {
  const vfs = resolver.installSource;
  if (!vfs) throw new Error("Import a Warcraft III install first (click the menu status text).");
  show("model");
  if (!modelScene) modelScene = new ModelViewerScene(modelCanvas, vfs);
  const sequences = await modelScene.load(path);
  modelScene.start();
  return sequences;
}

function showTerrain(): void {
  show("bg");
  placeholderTerrain().start();
}

/** Throw away the map canvas and put a fresh one in its place — the last and biggest thing a
 *  match leaves behind, and the two ways it shows.
 *
 *  **The picture.** A canvas holds the last frame drawn into it, and `enterMap` reveals this
 *  one (`show("map")`) BEFORE the next match's viewer exists, let alone its map — seconds, on
 *  a map that isn't cached. So the first thing the second game shows is the last thing the
 *  first game showed, frozen at the moment you quit. Whether a `preserveDrawingBuffer: false`
 *  buffer survives that is up to the driver, which is exactly why it must not be left to it: a
 *  canvas that has never been drawn to cannot show anything but the `#map { background: #000 }`
 *  underneath it, on any machine.
 *
 *  **The memory.** A WebGL context belongs to its CANVAS, and `getContext()` hands back the one
 *  already there — so building the next match's viewer on this element puts it on the DEAD
 *  match's context, alongside every texture, buffer and shader the last map uploaded.
 *  mdx-m3-viewer never deletes a GL object and offers no teardown, so replacing the element is
 *  the only release there is. `loseContext` makes it immediate rather than whenever the old
 *  canvas is collected, and it is why the two halves live in one function: a lost context
 *  cannot be got back, so nothing may ever ask THIS canvas for one again.
 *
 *  Everything about `#map` is styled by that id (style.css), so the replacement inherits the
 *  whole look. */
function freshMapCanvas(): void {
  const gl = mapCanvas.getContext("webgl2") ?? mapCanvas.getContext("webgl");
  gl?.getExtension("WEBGL_lose_context")?.loseContext();
  const next = document.createElement("canvas");
  next.id = "map";
  next.hidden = mapCanvas.hidden;
  mapCanvas.replaceWith(next);
  mapCanvas = next;
}

/**
 * Take the current match down — the half of leaving that is the same whatever comes next.
 *
 * Shared by `exitToMenu` (which then shows a glue screen) and by `changeLevel` (which then
 * starts the next chapter). It deliberately does NOT touch `pendingCampaign`: who the match
 * belonged to is the caller's business, and a chapter hand-off keeps the campaign.
 */
function endMatch(): void {
  const played = !!mapScene;
  mapScene?.dispose(); // …which silences the match's audio and flushes what it put on the page
  mapScene = null;
  // …and the canvas the match rendered into, WITH its WebGL context — but only if there was
  // one, since asking an untouched canvas for a context just to lose it would leave the next
  // match nothing to draw on.
  if (played) freshMapCanvas();
  meleeConfig = null;
  // The mixer is the one thing the match could move that isn't the match's to keep: a map's
  // VolumeGroupSetVolume / SetMusicVolume write to the very groups the player's saved Sound
  // options do (SoundBoard.endMatch says why it leaves them alone). This is the layer that
  // knows what the player chose, so this is where their levels come back.
  if (sounds) applyAudioOptions(sounds, loadOptions());
  // The match owned the relay connection from the moment the LAN screen handed it over, so
  // leaving the match is what closes it. Skipping this would leave the room listed and the
  // socket open behind a player who is back at the main menu.
  matchLink?.channel.close?.();
  matchLink = null;
  lan = null; // the wire the match owned is closed; a fresh LAN session opens a fresh one
  // …and the map's bytes go with it. `restartMatch` reads them BEFORE calling this, so the
  // one caller that still wants them has them; everyone else is leaving for good.
  lastMatch = null;
}

/** Leave the current match (F10 → End Game): tear down the map scene and return to
 *  the main menu over its animated 3D scene. A fresh scene is built next game.
 *
 *  `scores` puts the SCORE SCREEN between the two (issue #199) — handed over by every quit that
 *  asks for one (MapViewerScene.leave), and dismissed by its OK. */
/** The patch level a replay changed, to put back when it is left (`watchReplay`). */
let replayPatchWas: string | null = null;

function exitToMenu(scores: ScoreTable | null = null): void {
  endMatch();
  if (replayPatchWas !== null) {
    setPatchLevel(replayPatchWas);
    replayPatchWas = null;
  }
  // …and back onto the MELEE tables. The menus read object data too — the Custom Game screen's
  // map previews, the hotkey editor's cards, every tooltip — and the set a chapter left behind
  // is not the one the shell should be describing. The next match sets it again from its own
  // map (startGame).
  setMapDataSet("melee");
  document.body.classList.remove("in-game"); // reveal the main-menu panel again
  const vfs = resolver.installSource;
  // A campaign chapter returns to the chapter LIST it was started from — the reference drops
  // you back on the campaign screen, with the chapter you just finished now behind you.
  const campaign = pendingCampaign;
  pendingCampaign = null;
  const toMenu = (): void => void showMenuBackground(vfs).then(() => {
    if (!vfs) return;
    // glue.show() plays the chrome's Birth itself, so the DOM and the panel arrive together.
    if (campaign && campaignState) void glue.show(campaignScreen(vfs));
    else void glue.show(mainMenuScreen(vfs));
  });
  lastScores = scores ?? lastScores;
  if (scores && vfs) void showScoreScreen(vfs, scores).then(toMenu);
  else toMenu();
}

/**
 * The score screen (ui/scoreScreen.ts), up on the loading screen's layer and canvas — the other
 * full-window picture that stands between the menus and a match, and idle whenever this one is.
 * Resolves on OK. A screen that cannot be built (the install lacks its art) is skipped rather
 * than leaving the player on a black window.
 */
/** The last score table shown — kept for the `window.warcraftOpen.scoreScreen()` probe, which puts the
 *  screen back up without playing a match to its end again. */
let lastScores: ScoreTable | null = null;

async function showScoreScreen(vfs: DataSource, table: ScoreTable): Promise<void> {
  show("none");
  try {
    let done: () => void = () => {};
    const ok = new Promise<void>((resolve) => { done = resolve; });
    // The match just played, when it was recorded: Save Replay keeps it under a name. The name
    // offered is the map's and when it was played (render/mapViewer.ts `suggestedName`).
    const rec = lastRecordedReplay();
    const screen = await (isHd() ? mountHdScoreScreen : mountScoreScreen)({
      container: loadingLayer, canvas: loadingCanvas, vfs, table,
      localPlayer: table.viewer, onOk: () => done(),
      replay: rec ? { sink: rec.sink, written: rec.written, suggested: rec.suggested } : undefined,
    });
    loadingCanvas.hidden = false;
    // The featured race's VictoryMusic / DefeatMusic (war3skins) under it, as the reference plays.
    const music = scoreScreenMusic(vfs, table, table.viewer);
    if (music) sounds?.playMusic(music);
    await ok;
    glueAudio?.click();
    // Leave through BLACK: the screen fades out where it stands, and the menu's own cover takes
    // over at full black before the screen comes down — the score screen lives on the loading
    // screen's layer, above the menus' fade, so the menu is built under black and the black
    // lifts as its panels arrive (Glue.show). The duration is the edition switch's: this too is
    // the whole picture changing under the player, not a cut between two screens of one menu.
    await fadeOutLayer(loadingLayer, WORLD_FADE_MS);
    await glue.cover();
    screen.dispose();
  } catch (err) {
    console.warn("[Warcraft Open] score screen unavailable:", err);
  }
  loadingCanvas.hidden = true;
  loadingLayer.querySelector(".score-fade")?.remove();
}

/** Bring a black veil up over everything on `layer` (the loading layer's canvas sits under it
 *  too) and resolve once it is opaque. The caller removes it. */
async function fadeOutLayer(layer: HTMLElement, ms: number): Promise<void> {
  const veil = document.createElement("div");
  veil.className = "glue-fade score-fade";
  veil.style.transitionDuration = `${ms}ms`;
  veil.style.zIndex = "1000"; // over the score screen's own frames, which stack inside this layer
  layer.appendChild(veil);
  void veil.offsetWidth; // commit the transparent start, or the fade is a cut
  veil.classList.add("glue-fade-on");
  await new Promise((r) => setTimeout(r, ms));
}

// Boot flow (issue #54): the WC3 menus are constructed from the install's own
// UI\FrameDef\*.fdf files, so we gate on loading the game files first — a single
// button over the flying terrain — then build the FDF main menu and continue.
let gate: { dispose(): void } | null = null;
// The DESKTOP front page (src/ui/home.ts) — the site's layout with the launcher's own buttons.
let home: Home | null = null;

/** Build the authentic FDF-driven main menu; fall back to the flat skin if the install
 *  lacks the glue files or the FDF fails to construct. Every screen the game can reach is
 *  now built from the FrameDef — the Custom Game screen included — so the flat menu is a
 *  diagnostic, not a second way to play: it can only tell the player what's missing. */
async function showMainMenu(vfs: DataSource): Promise<void> {
  try {
    await glue.show(mainMenuScreen(vfs));
  } catch (err) {
    console.warn("[Warcraft Open] FDF main menu unavailable, using flat menu:", err);
    mountMainMenu(ui, resolver, {
      onSinglePlayer: () => window.alert(t("error.glueFilesMissing")),
    });
  }
}

/** Everything mounting an install sets up EXCEPT showing the menu: the resolver, the map list,
 *  the cursor and the audio. Split out from onFilesLoaded because a scripted boot that goes
 *  straight into a match (src/dev/devBoot.ts) needs all of this and none of the menu. */
function mountInstall(load: GateLoad): void {
  resolver.setInstall(load.vfs);
  installMaps = load.maps; // the Custom Game screen's map list
  installFlavour = load.flavour; // …and which game files a replay says it was played on
  setGameVersion(load.gameVersion); // …and the exact build an HD room puts on the wire
  ((window as unknown as { warcraftOpen: Record<string, unknown> }).warcraftOpen ??= {}).vfs = load.vfs;
  gate?.dispose();
  gate = null;
  home?.dispose();
  home = null;
  applyMenuCursor(load.vfs); // WC3 human hand cursor in the menus
  applyGameFont(load.vfs); // Friz Quadrata TT, out of the install's own Fonts\ (issue #72)
  // Every `setGameTip` hover hint from here on wears the game's tooltip art (the command card's border strip
  // and fill), menus included — the update prompt's release link is up before any screen that
  // could otherwise have dressed it (src/ui/updatePrompt.ts).
  setGameTipSkin(tooltipSkinVars((path) => {
    const bytes = load.vfs.rawBytes(path);
    return bytes ? blpToCanvas(bytes) : null;
  }));
  // Audio: every sound comes out of the archives, so this is the first moment it can exist.
  // The gate button the player just pressed is also the gesture that opens the browser's
  // autoplay gate, so the theme can start with the menu.
  sounds = new SoundBoard(load.vfs);
  // Honour the volumes/toggles the player saved last time (issue #81) from the very first
  // sound — before the menu theme starts below, so it comes up at the chosen music volume.
  applyAudioOptions(sounds, loadOptions());
  glueAudio = new GlueAudio(sounds, load.vfs);
  setFdfClickSound(() => glueAudio?.click()); // every FDF button, menu and in-game alike
  // Open the audio context NOW, on the gesture that got us here, and not at the first sound.
  // Resuming it is asynchronous, and the first sound the menu makes is the whoosh on the very
  // first frame of the main menu's Birth — ask for the context only then and that whoosh is
  // played into a context that is still suspended, i.e. dropped. The model load below buys the
  // resume all the time it needs.
  sounds.unlock();
}

/** Bring up the main menu over its animated 3D scene. The scene has to exist before the menus
 *  do: it owns the panel chrome whose Birth/Death clips time their transitions (ui/glue.ts). */
function showMenu(load: GateLoad): void {
  void showMenuBackground(load.vfs).then(() => {
    glue.setScene(menuScene);
    void showMainMenu(load.vfs);
    // The desktop app asked GitHub for a newer version seconds after launch; this is the first
    // moment there is a screen worth interrupting, and the game's own message box to do it in
    // (src/ui/updatePrompt.ts). A no-op in a browser, which updates by being reloaded.
    watchForUpdates(ui, load.vfs);
  });
}

/** Hand off from the launcher to the main menu once the archives are mounted. */
function onFilesLoaded(load: GateLoad): void {
  mountInstall(load);
  showMenu(load);
}

// The right mouse button belongs to the GAME (it is the move/attack order), and a game has no
// browser context menu — anywhere, on any surface: the 3D canvas, the HUD, the menus. The
// individual canvases already swallowed it; this closes the rest of the page.
window.addEventListener("contextmenu", (e) => e.preventDefault());

// The rest of the browser's document gestures, for the same reason: a press-and-drag across the
// screen is a selection box in the world, not a highlight of the words over it; a selected word
// dragged towards the tab strip must not become a search or a navigation; a link or an icon
// dropped on the page must not ghost its way there. Inputs keep their own selection, and the
// caret's own gestures, untouched.
const isTextField = (target: EventTarget | null): boolean => {
  const el = target instanceof Element ? target : null;
  const field = el?.closest("input, textarea, [contenteditable='true']");
  return !!field;
};
window.addEventListener("selectstart", (e) => { if (!isTextField(e.target)) e.preventDefault(); });
window.addEventListener("dragstart", (e) => { if (!isTextField(e.target)) e.preventDefault(); });

// Ctrl+wheel zooms the PAGE, and over a game that is only ever an accident (the wheel itself
// belongs to the camera and the HUD's lists).
window.addEventListener("wheel", (e) => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });

// The rest of the SCREEN-LEVEL gestures — the ones a browser page has and a game must not. A page
// that only ever draws a game has no document to pan, pinch, double-tap or key-zoom, and each of
// those would otherwise land on the frame the player is commanding. The shell has none of them,
// so none of this is registered there.
if (!isDesktopApp()) {
  // Safari announces a trackpad pinch as `gesture*`, NOT as a ctrl+wheel — the only way to
  // refuse it is by name. Chrome's ctrl+wheel is already above.
  for (const type of ["gesturestart", "gesturechange", "gestureend"]) {
    window.addEventListener(type, (e) => e.preventDefault(), { passive: false });
  }
  // Pinch on a touch screen arrives as two pointers on the page rather than as a wheel.
  window.addEventListener("touchmove", (e) => { if (e.touches.length > 1) e.preventDefault(); }, { passive: false });
  // The browser's zoom KEYS (Cmd/Ctrl with +/-/0), which the wheel listener cannot see. Text fields
  // keep them: a player typing a name may still use their own shortcuts.
  window.addEventListener("keydown", (e) => {
    if (!(e.metaKey || e.ctrlKey) || e.altKey || isTextField(e.target)) return;
    if (e.key === "+" || e.key === "-" || e.key === "=" || e.key === "0") e.preventDefault();
  });
}

// The browser's own autofill and spell-check dropdowns over the game's text fields: the game
// draws its own console, and a password manager's card or a red squiggle under a player's name
// is not part of it. Each field still works exactly as before; only the page's suggestions go.
window.addEventListener("focusin", (e) => {
  const el = e.target;
  if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement)) return;
  el.setAttribute("autocomplete", "off");
  el.setAttribute("autocorrect", "off");
  el.setAttribute("autocapitalize", "off");
  el.setAttribute("spellcheck", "false");
  el.setAttribute("data-gramm", "false");
  el.setAttribute("data-gramm_editor", "false");
  el.setAttribute("data-enable-grammarly", "false");
});

// A gamepad (issue #162) may be paired from any screen — the menus as much as a match — so its
// poll runs for the life of the page. See ui/gamepad.ts.
startGamepad();

// The mouse is confined to the page during a match with the Pointer Lock API — the OS pointer
// otherwise walks out of a windowed page over the title bar, or onto the menu bar of a second
// display in fullscreen, and edge scroll stops. Wired at start-up so its listeners come before
// the match's own; it takes the pointer on the first click in the game. See ui/mouseCapture.ts.
installMouseCapture();

// Boot. Normally the load gate: a human picks their Warcraft III folder, because that gesture
// is also what opens the browser's autoplay gate. Under `?dev` on a DEV SERVER ONLY, a scripted
// boot fetches the install over HTTP instead, so the game can be driven — and driven twice at
// once, from two player slots — by automation. `import.meta.env.DEV` is a compile-time constant
// that Vite folds to `false` for `pnpm build`, so this branch and the dynamic import inside it
// are dropped from the bundle entirely; there is no path from a shipped artifact to an asset
// route. See src/dev/devBoot.ts and tools/vite-plugin-dev-install.ts.
if (replayBridge()) {
  // A REPLAY WINDOW: another version's replay, opened by a later desktop app in this version's
  // own page (src/replayBoot.ts). It watches the one replay it is handed and nothing else.
  void replayBoot(ui, replayBridge()!, { mountInstall, watchReplay });
} else if (import.meta.env.DEV && new URLSearchParams(location.search).has("dev")) {
  void import("./dev/devBoot")
    .then((m) =>
      m.devBoot({
        mountInstall,
        showMenu,
        startGame: (file, info, config, link, mapPath) => startGame(file, info, config, link, undefined, mapPath),
        watchReplay,
        startChapter,
        startCredits: () => startCredits(resolver.installSource!),
      }),
    )
    .catch((err) => {
      console.error("[dev-boot] failed:", err);
      gate = mountLoadGate(ui, onFilesLoaded); // fall back to the human path
    });
} else {
  // The launcher's front page is the same page in the browser: /play/ opens on it, and the
  // folder picker is the Launch press itself (src/ui/home.ts startBrowser). A remembered folder
  // is re-opened by that press rather than for the player, so "/" is always the same screen and
  // never a redirect into the middle of a game.
  home = mountHome(ui, onFilesLoaded);
}

// Console hooks for the phase exit criteria (see README "Testing manually").
(window as unknown as { warcraftOpen: Record<string, unknown> }).warcraftOpen = {
  resolver,
  decodeBlp,
  listModels,
  viewModel,
  setSequence: (index: number) => modelScene?.setSequence(index),
  showTerrain,
  loadMap: async (file: File) => enterMap(new Uint8Array(await file.arrayBuffer()), file.name),
  meleeConfig: () => meleeConfig,
  mainMenu: () => glue.screen,
  menuScene: () => menuScene,
  mapScene: () => mapScene, // the live match, for the two-client LAN harness's eval probes
  matchLink: () => matchLink, // …and its wire: `.channel.isDirect(peer)` / `.counts` (net/directLink.ts)
  // The score screen again, over whatever is up, on the last table (or one handed in) — a probe
  // for laying it out without finishing a match each time. Resolves on its OK.
  scoreScreen: (table?: ScoreTable) => {
    const vfs = resolver.installSource;
    const t = table ?? lastScores;
    // Over a menu that is already up there is no `show` to lift the black it leaves through.
    return vfs && t ? showScoreScreen(vfs, t).then(() => glue.uncover()) : Promise.resolve();
  },
  lastScores: () => lastScores,
  // Watch a replay out of the replay folder by its file name (issue #158).
  watchReplay: async (name = "LastReplay.o3r") => {
    const bytes = await replaySink()?.read(name);
    if (!bytes) throw new Error(`no replay named ${name}`);
    const replay = await decodeReplay(bytes);
    refuseOtherLine(replay);
    await watchReplay(replay);
  },
  // Voice Control's mapping without a microphone (src/voice/control.ts).
  voiceSay,
  voicePreroll: voicePrerollState,
  voiceHear,
};
